from __future__ import annotations

import enum
import logging
import typing

import requests

from adp.public.common import sdk_errors

_LOGGER = logging.getLogger("SdkCommon")
_LOGGER.setLevel(logging.INFO)

_HEADERS = {"Content-Type": "application/json", "Accept": "application/json"}


SUCCESSFUL_REQUEST_CODE = 200
SUCCESSFUL_CREATED_CODE = 201


class ApiVersion(enum.Enum):
    UNSET = 0
    LOCAL = 1
    CLOUD = 2


class CommonApiEndpoints(enum.Enum):
    VERSION = "version"


LOCAL_HTTP_HEADER = "http://"
CLOUD_HTTP_HEADER = "https://"

LOCAL_API_URL = "{http_header}{api_endpoint}/v1/{endpoint}"
V2_API_URL = "{http_header}{api_endpoint}/api/v2/{endpoint}"


def _get_api_request(
    api_endpoint: str,
    endpoint: str,
    params: typing.Optional[dict],
    headers: dict,
    api_version: ApiVersion,
) -> requests.Response:
    if api_version == ApiVersion.LOCAL:
        api_url = LOCAL_API_URL.format(
            http_header=LOCAL_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    elif api_version == ApiVersion.CLOUD:
        api_url = V2_API_URL.format(
            http_header=CLOUD_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    else:
        raise Exception("Unsupported api version: %s.", api_version)
    try:
        response = requests.get(api_url, headers=headers, params=params)
    except requests.exceptions.ConnectionError:
        raise sdk_errors.ADPUnavailableError(
            f"Unable to connect to API endpoint {api_endpoint}. Ensure this API endpoint is available."
        )
    return response


def _post_api_request(
    api_endpoint: str,
    endpoint: str,
    request: typing.Optional[dict],
    headers: dict,
    api_version: ApiVersion,
) -> requests.Response:
    if api_version == ApiVersion.LOCAL:
        api_url = LOCAL_API_URL.format(
            http_header=LOCAL_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    elif api_version == ApiVersion.CLOUD:
        api_url = V2_API_URL.format(
            http_header=CLOUD_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    else:
        raise Exception("Unsupported api version: %s.", api_version)
    try:
        if request is not None:
            response = requests.post(
                api_url,
                json=request,
                headers=headers,
            )
        else:
            response = requests.get(
                api_url,
                headers=headers,
            )
    except requests.exceptions.ConnectionError:
        raise sdk_errors.ADPUnavailableError(
            f"Unable to connect to API endpoint {api_endpoint}. Ensure this API endpoint is available."
        )
    return response


def _put_api_request(
    api_endpoint: str,
    endpoint: str,
    request: typing.Optional[dict],
    headers: dict,
    api_version: ApiVersion,
) -> requests.Response:
    if api_version == ApiVersion.LOCAL:
        api_url = LOCAL_API_URL.format(
            http_header=LOCAL_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    elif api_version == ApiVersion.CLOUD:
        api_url = V2_API_URL.format(
            http_header=CLOUD_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    else:
        raise Exception("Unsupported api version: %s.", api_version)
    try:
        response = requests.put(
            api_url,
            json=request,
            headers=headers,
        )
    except requests.exceptions.ConnectionError:
        raise sdk_errors.ADPUnavailableError(
            f"Unable to connect to API endpoint {api_endpoint}. Ensure this API endpoint is available."
        )
    return response


def _delete_api_request(
    api_endpoint: str,
    endpoint: str,
    headers: dict,
    api_version: ApiVersion,
    request: dict | None = None,
) -> requests.Response:
    if api_version == ApiVersion.LOCAL:
        api_url = LOCAL_API_URL.format(
            http_header=LOCAL_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    elif api_version == ApiVersion.CLOUD:
        api_url = V2_API_URL.format(
            http_header=CLOUD_HTTP_HEADER, api_endpoint=api_endpoint, endpoint=endpoint
        )
    else:
        raise Exception("Unsupported api version: %s.", api_version)
    try:
        response = requests.delete(
            api_url,
            json=request,
            headers=headers,
        )
    except requests.exceptions.ConnectionError:
        raise sdk_errors.ADPUnavailableError(
            f"Unable to connect to API endpoint {api_endpoint}. Ensure this API endpoint is available."
        )
    return response


def _get_content_from_response(response: requests.Response) -> typing.Any:
    content = None
    try:
        content = response.json()
    except ValueError:  # includes simplejson.decoder.JSONDecodeError
        _LOGGER.exception("Error parsing response from request")
    assert content is not None
    common_response = content.get("common", None)
    # Error checking for legacy GRPC format where we return status 200 and have to check the proto for exceptions or successes.
    if common_response is not None:
        status = content.get("common", {}).get("status")
        if status != "SUCCESS":
            errorMsg = content.get("errorMsg")
            if errorMsg:
                _LOGGER.error("Error executing request: %s", errorMsg)
                return
            elif content["common"].get("exception"):
                _LOGGER.error(
                    "Error executing request: %s",
                    content["common"]["exception"]["exceptionMessage"],
                )
                return
            else:
                _LOGGER.error("Unexpected error executing request: %s.", status)
                return
    return content


T = typing.TypeVar("T", bound=enum.Enum)


class SdkBase(typing.Generic[T]):
    """
    This SDK base can be inherited to interact with the local and cloud REST APIs.

    T is the type of an enum that holds allowed REST API endpoints that is used by the SDK.

    Example:

        from adp.public.common import sdk_helpers

        import enum

        class API_ENDPOINTS(enum.Enum):
            EXAMPLE = "example"


        class ExampleSdk(sdk_helpers.SdkBase[API_ENDPOINTS]):

            def example_endpoint(self, args):
                return self.post_request(API_ENDPOINTS.EXAMPLE, args)

    """

    _auth_token: str
    _api_endpoint: str
    _remote_hostname: str
    _api_version: ApiVersion
    _headers: dict[str, str]

    def __init__(
        self,
        auth_token: str = "",
        api_endpoint: str = "",
        remote_hostname: str = "",
        is_cloud: bool = True,
    ):
        """Creates a Base API client with helpers to interact with the local and cloud REST APIs.

        [#tags] Public

        Args:
            auth_token (str): ADP auth token. This token can be found under the
                                profile icon in ADPHome or you can programatically generate a [machine credential](https://home.applied.co/manual/adp/latest/#/integrating_with_adp/machine_authorization/machine_authorization?id=machine-authorization).
            api_endpoint (str): The API base endpoint of the remote simulator.
                                Typically the `{}` in `https://{}/api`.
            remote_hostname (str): The remote hostname pointing to the running ADP instance
                                you are trying to access. Typically the {} in `https://{}/adp/results`.
            is_cloud (bool): Whether the remote hostname is a cloud-based ADP instance or a
                                local-based ADP instance.

        Raises:
            ADPUnavailableError: If client is unable to connect to ADP.
        """

        self._auth_token = auth_token
        self._api_endpoint = api_endpoint
        self._remote_hostname = remote_hostname

        if is_cloud:
            self._api_version = ApiVersion.CLOUD
        else:
            self._api_version = ApiVersion.LOCAL

        self._headers = self._get_headers()

        if not self._validate_auth_token():
            raise sdk_errors.ADPUnavailableError(
                f"Check that your auth token is valid and the cluster's API endpoint is available at {self._api_endpoint}."
            )

        if not remote_hostname:
            _LOGGER.exception("Remote hostname must be specified.")
            return

    def _get_headers(self) -> dict[str, str]:
        """Gets headers base on the ApiVersion. See documentation on [how to
        authenticate to the REST API](https://home.applied.co/manual/adp/latest/#/apis/rest_api/rest_api?id=usage).

        Returns:
            dict[str, str]: A dictionary representing HTTP Authentication headers.
        """
        headers = _HEADERS

        if self._api_version == ApiVersion.LOCAL:
            # TODO(littke) remove this once we validate we no longer need it.
            headers["Cookie"] = f"auth_token={self._auth_token}"
            headers["Authorization"] = f"Bearer {self._auth_token}"
        elif self._api_version == ApiVersion.CLOUD:
            headers["Authorization"] = f"Bearer {self._auth_token}"
        return headers

    def _get_host_url(self) -> str:
        """Gets host URL the SDK Client connects to.

        Returns:
            str: Host URL.
        """
        header = LOCAL_HTTP_HEADER if self._api_version == ApiVersion.LOCAL else CLOUD_HTTP_HEADER
        return "{}{}".format(header, self._remote_hostname)

    def get_request(
        self,
        endpoint_enum: T | CommonApiEndpoints,
        params: typing.Optional[dict] = None,
        error_msg: str = "Error getting resource",
    ) -> typing.Any:
        """Sends a get request to the specified API endpoint.

        [#tags] Public

        Args:
            endpoint (API_ENDPOINTS): The API endpoint to send the request to.
            params (dict | None, optional): Query params to send. Defaults to None.
            error_msg (str, optional): An error message to display if the request fails. Defaults to "Error getting resource".

        Returns:
            typing.Any | None: The response from the API get request.

        Example:
            response = sdk_client.get_request(
                endpoint=API_ENDPOINTS.EXPORT_COLLECTION,
                params={
                    "id": 92,
                },
                error_msg="Error getting export collection logs",
            )
        """

        response = _get_api_request(
            self._api_endpoint,
            endpoint_enum.value,
            params,
            self._headers,
            self._api_version,
        )
        if (
            response.status_code != SUCCESSFUL_REQUEST_CODE
            and response.status_code != SUCCESSFUL_CREATED_CODE
        ):
            _LOGGER.error(
                "Error with get request to %s: %s: %s. %s.",
                endpoint_enum,
                error_msg,
                response.status_code,
                response.content,
            )
            raise sdk_errors.ADPHttpError(f"Http error with status code {response.status_code}")
        return _get_content_from_response(response)

    def post_request(
        self,
        endpoint_enum: T | CommonApiEndpoints,
        request: typing.Optional[dict] = None,
        error_msg: str = "Error posting request",
    ) -> typing.Any:
        """Sends a post request to the specified API endpoint.

        [#tags] Public

        Args:
            endpoint (API_ENDPOINTS): The API endpoint to send the request to.
            request (dict | None, optional): The request to send. Defaults to None.
            error_msg (str, optional): An error message to display if the request fails. Defaults to "Error posting request".

        Returns:
            typing.Any | None: The response from the API post request.

        Example:
            response = sdk_client.post_request(
                endpoint=API_ENDPOINTS.EXPORT_COLLECTION,
                request={
                    "id": 92,
                },
                error_msg="Error exporting collection 92",
            )
        """

        response = _post_api_request(
            self._api_endpoint,
            endpoint_enum.value,
            request,
            self._headers,
            self._api_version,
        )
        if (
            response.status_code != SUCCESSFUL_REQUEST_CODE
            and response.status_code != SUCCESSFUL_CREATED_CODE
        ):
            _LOGGER.error(
                "Error posting request to %s: %s: %s. %s.",
                endpoint_enum,
                error_msg,
                response.status_code,
                response.content,
            )
            return None
        return _get_content_from_response(response)

    def post_request_with_path_parameters(
        self,
        endpoint_enum: T | CommonApiEndpoints,
        params: list[str],
        request: typing.Optional[dict] = None,
        error_msg: str = "Error posting request",
    ) -> typing.Any:
        """Sends a post request to the specified API endpoint.

        [#tags] Public

        Args:
            endpoint (API_ENDPOINTS): The API endpoint to send the request to.
            request (dict | None, optional): The request to send. Defaults to None.
            error_msg (str, optional): An error message to display if the request fails. Defaults to "Error posting request".

        Returns:
            typing.Any | None: The response from the API post request.

        Example:
            response = sdk_client.post_request(
                endpoint=API_ENDPOINTS.EXPORT_COLLECTION,
                request={
                    "id": 92,
                },
                error_msg="Error exporting collection 92",
            )
        """

        request_endpoint = endpoint_enum.value.format(*params)

        response = _post_api_request(
            self._api_endpoint,
            request_endpoint,
            request,
            self._headers,
            self._api_version,
        )
        if response.status_code != SUCCESSFUL_REQUEST_CODE:
            _LOGGER.error(
                "Error posting request to %s: %s: %s. %s.",
                endpoint_enum,
                error_msg,
                response.status_code,
                response.content,
            )
            return None
        return _get_content_from_response(response)

    def put_request(
        self,
        endpoint_enum: T | CommonApiEndpoints,
        request: typing.Optional[dict] = None,
        error_msg: str = "Error sending request",
    ) -> typing.Any:
        """Sends a put request to the specified API endpoint.

        [#tags] Public

        Args:
            endpoint (API_ENDPOINTS): The API endpoint to send the request to.
            request (dict | None, optional): The request to send. Defaults to None.
            error_msg (str, optional): An error message to display if the request fails. Defaults to "Error sending request".

        Returns:
            typing.Any | None: The response from the API put request.

        Example:
            response = sdk_client.put_request(
                endpoint=API_ENDPOINTS.PLUGIN_QUEUE,
                request={
                    "plugin_queue": {
                        "name": "queue1",
                    }
                },
                error_msg="Error updating plugin queue",
            )

        """
        response = _put_api_request(
            self._api_endpoint,
            endpoint_enum.value,
            request,
            self._headers,
            self._api_version,
        )
        if (
            response.status_code != SUCCESSFUL_REQUEST_CODE
            and response.status_code != SUCCESSFUL_CREATED_CODE
        ):
            _LOGGER.error(
                "Error processing PUT request to %s: %s: %s. %s.",
                endpoint_enum,
                error_msg,
                response.status_code,
                response.content,
            )
            return None
        return _get_content_from_response(response)

    def put_request_with_path_parameters(
        self,
        endpoint_enum: T | CommonApiEndpoints,
        params: list[str],
        request: typing.Optional[dict] = None,
        error_msg: str = "Error posting request",
    ) -> typing.Any:
        """Sends a put request to the specified API endpoint.

        [#tags] Public

        Args:
            endpoint (API_ENDPOINTS): The API endpoint to send the request to.
            request (dict | None, optional): The request to send. Defaults to None.
            error_msg (str, optional): An error message to display if the request fails. Defaults to "Error posting request".

        Returns:
            typing.Any | None: The response from the API put request.

        Example:
            response = sdk_client.put_request_with_path_parameters(
                endpoint_enum=API_ENDPOINTS.UPDATE_COLLECTION_PERMISSIONS,
                params=['some-uuid'],
                error_msg=f"Error granting permissions on collection with uuid",
                request={
                    "collection_permissions": {
                        "user_roles": [],
                    }
                },
            )
        """

        request_endpoint = endpoint_enum.value.format(*params)

        response = _put_api_request(
            self._api_endpoint,
            request_endpoint,
            request,
            self._headers,
            self._api_version,
        )
        if response.status_code != SUCCESSFUL_REQUEST_CODE:
            _LOGGER.error(
                "Error putting request to %s: %s: %s. %s.",
                endpoint_enum,
                error_msg,
                response.status_code,
                response.content,
            )
            return None
        return _get_content_from_response(response)

    def delete_request_with_query_parameters(
        self,
        endpoint_enum: T | CommonApiEndpoints,
        params: list[str],
        error_msg: str = "Error posting delete request",
        request: dict | None = None,
    ) -> typing.Any:
        request_endpoint = endpoint_enum.value.format(*params)

        response = _delete_api_request(
            self._api_endpoint,
            request_endpoint,
            self._headers,
            self._api_version,
            request,
        )
        if response.status_code != SUCCESSFUL_REQUEST_CODE:
            _LOGGER.error(
                "Error posting delete request to %s: %s: %s. %s.",
                endpoint_enum,
                error_msg,
                response.status_code,
                response.content,
            )
            return None
        return _get_content_from_response(response)

    def _validate_auth_token(self) -> bool:
        """Submit a POST request to validate the auth token.

        Returns:
            bool: True if the auth_token is valid, False otherwise.
        """
        _LOGGER.info("Validating authentication token.")

        response = self.post_request(CommonApiEndpoints.VERSION)
        _LOGGER.info("Received response from authentication validation: %s", response)
        if response:
            return True
        return False
