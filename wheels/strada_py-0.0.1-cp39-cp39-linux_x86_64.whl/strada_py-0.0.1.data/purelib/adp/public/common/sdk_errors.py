from __future__ import annotations


class ADPSDKError(Exception):
    """
    Generic error that encompasses all the custom errors that the SDK can throw.
    """

    pass


class ADPInvalidArgumentError(ADPSDKError):
    """
    Invalid argument provided.
    """

    pass


class ADPBugError(ADPSDKError):
    """
    Unexpected error. File an issue in the Applied issue tracker: https://home.applied.co/issues.
    """

    pass


class ADPUnavailableError(ADPSDKError):
    """
    ADP server is unavailable. This can happen when an incorrect URL is provided, an incorrect auth token is provided, the local ship is not running, or when the cloud cluster is down.
    """

    pass


class ADPAuthTokenInvalid(ADPSDKError):
    """
    This occurs when the provided auth token is invalid. See [docs](https://home.applied.co/manual/adp/latest/#/integrating_with_adp/machine_authorization#authtoken) to get a valid auth token.
    """

    pass


class ADPAuthTokenExpired(ADPAuthTokenInvalid):
    """
    This occurs when the provided auth token is has expired. Auth tokens expire after 2 weeks. See [docs](https://home.applied.co/manual/adp/latest/#/integrating_with_adp/machine_authorization#authtoken) to get a new auth token.
    """

    pass


class ADPHttpError(ADPSDKError):
    """
    Generic Http Error
    """

    pass
