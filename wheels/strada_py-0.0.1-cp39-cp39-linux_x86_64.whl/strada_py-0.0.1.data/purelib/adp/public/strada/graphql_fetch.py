"""
GraphQL data fetching classes and helper functions.

Copyright (C) 2025 Applied Intuition, Inc. All rights reserved.
This source code file is distributed under and subject to the LICENSE in
license.txt
"""

from __future__ import annotations

from datetime import datetime
from datetime import timezone
import json
import logging
import typing
from typing import Callable, Union

from dateutil import parser as dateutil_parser

from adp.public.strada.client_constants import FETCH_ITEMS_QUERY_PAGE_SIZE
from adp.public.strada.client_constants import QUERY_STRINGS
from adp.public.strada.models import custom_field_models
from adp.public.strada.models.object_models import Log
from adp.public.strada.models.object_models import LogPath
from adp.public.strada.models.triage_models import EventRelativeOffset
from adp.public.strada.models.triage_models import EventUUID
from adp.public.strada.models.triage_models import TriageEvent

_LOGGER = logging.getLogger("StradaClient")
_LOGGER.setLevel(logging.INFO)

# Type variable for fetch items, constrained to either Log or TriageEvent
_FetchItemType = typing.TypeVar("_FetchItemType", bound=typing.Union[Log, TriageEvent])

_PostQueryRequest = Callable[[str, Union[str, None]], dict]


def _get_log_from_node(node: dict) -> Log | None:
    """Extract Log object from a node in the query response."""
    log_id = node.get("id")
    if not log_id:
        raise RuntimeError("Log result does not have corresponding id %s", str(node))
    latest_drive_run = node.get("latestDriveRun")
    if not latest_drive_run:
        _LOGGER.debug("Log result does not have corresponding latestDriveRun  %s", str(node))
        return None
    simulation_run = latest_drive_run.get("simulationRun")
    if not simulation_run:
        _LOGGER.debug("Log result does not have corresponding simulationRun  %s", str(node))
        return None

    custom_fields = [
        custom_field_models.CustomFieldFactory.create_custom_field_from_name_value_pair(
            name=field.get("fieldDefinition", {}).get("name"),
            is_user_editable=field.get("fieldDefinition", {}).get("userEditable", False),
            source_type=field.get("fieldDefinition", {}).get("sourceType", ""),
            value=field.get("value"),
        )
        for field in simulation_run.get("customFields", [])
    ]
    tags = [tag.get("tag", {}).get("name") for tag in simulation_run.get("simulationRunTags", [])]

    return Log(
        uuid=latest_drive_run.get("uuid"),
        log_path=node.get("logPath"),
        simulation_run_id=latest_drive_run.get("simulationRun").get("id"),
        created_at=latest_drive_run.get("createdAt"),
        start_time=latest_drive_run.get("startTime"),
        vehicle_name=latest_drive_run.get("vehicleName"),
        tags=tags,
        custom_fields=custom_fields,
    )


def _get_event_from_node(node: dict) -> TriageEvent | None:
    """Extract TriageEvent object from a node in the query response."""
    uuid = node.get("uuid")
    if not uuid:
        return None

    custom_fields = [
        custom_field_models.CustomFieldFactory.create_custom_field_from_name_value_pair(
            name=field.get("fieldDefinition", {}).get("name"),
            is_user_editable=field.get("fieldDefinition", {}).get("userEditable", False),
            source_type=field.get("fieldDefinition", {}).get("sourceType", ""),
            value=field.get("value"),
        )
        for field in node.get("customFields", [])
    ]
    tags = [tag.get("tag", {}).get("name") for tag in node.get("triageEventTags", [])]

    root_causes = [cause.get("name") for cause in node.get("rootCauses", [])]

    metadata = json.loads(node.get("metadataInfo", "{}")) if node.get("metadataInfo") else {}

    assignee = node.get("assignee")
    assignee_email = assignee.get("email") if assignee is not None else None

    time_secs = 0.0
    time_val = node.get("time")
    if time_val is not None:
        time_dt = dateutil_parser.parse(str(time_val)).replace(tzinfo=timezone.utc)
        time_secs = (time_dt - datetime.fromtimestamp(0, tz=timezone.utc)).total_seconds()

    start_time_secs = 0.0
    start_time_val = node.get("startTime")
    if start_time_val is not None:
        start_time_dt = dateutil_parser.parse(str(start_time_val)).replace(tzinfo=timezone.utc)
        start_time_secs = (
            start_time_dt - datetime.fromtimestamp(0, tz=timezone.utc)
        ).total_seconds()

    end_time_secs = 0.0
    end_time_val = node.get("endTime")
    if end_time_val is not None:
        end_time_dt = dateutil_parser.parse(str(end_time_val)).replace(tzinfo=timezone.utc)
        end_time_secs = (end_time_dt - datetime.fromtimestamp(0, tz=timezone.utc)).total_seconds()

    return TriageEvent(
        uuid=uuid,
        relative_offset=EventRelativeOffset(
            time_secs=time_secs,
            start_time_secs=start_time_secs,
            end_time_secs=end_time_secs,
        ),
        from_disengagement=node.get("fromDisengagement", False),
        reason=node.get("reason"),
        location=TriageEvent.Location(
            lat=node.get("lat"),
            lng=node.get("lng"),
        ),
        assignee_email=assignee_email,
        root_causes=root_causes,
        custom_fields=custom_fields,
        driver_comment=node.get("driverComment"),
        tags=tags,
        key=node.get("simpleIdentifierV2"),
        metadata=metadata,
    )


def iter_fetch_items(
    post_query_request: _PostQueryRequest,
    item_type: typing.Type[_FetchItemType],
    adp_search_term: str,
    item_identifiers: list[LogPath] | list[EventUUID] | None = None,
) -> typing.Iterator[_FetchItemType]:
    """
    Iterator function that fetches the items of the selected type which matching the provided search term.
    The iterator yields a log metadata object for each item
    Pagination is handled internally.
    """
    identifiers_filter = ""
    if item_type == Log:
        query_template = QUERY_STRINGS["fetch_logs_from_search_term"]
        connection_name = "logConversionsConnection"

        if item_identifiers is not None:
            if not all(isinstance(identifier, LogPath) for identifier in item_identifiers):
                raise ValueError("Identifiers must be LogPath objects when fetching logs")

            identifier_values = [log_path.value for log_path in item_identifiers]
            identifiers_filter = f"logPathInList:{json.dumps(identifier_values)}"
    elif item_type == TriageEvent:
        query_template = QUERY_STRINGS["fetch_events_from_search_term"]
        connection_name = "triageEventsConnection"

        if item_identifiers is not None:
            if not all(isinstance(identifier, EventUUID) for identifier in item_identifiers):
                raise ValueError("Identifiers must be EventUUID objects when fetching events")

            identifier_values = [event_uuid.value for event_uuid in item_identifiers]
            identifiers_filter = f"uuidInList:{json.dumps(identifier_values)}"
    else:
        raise ValueError("Invalid item type")

    after_cursor = ""
    has_next_page = True
    retrieved_item_count = 0

    while has_next_page:
        query = query_template.format(
            page_size=FETCH_ITEMS_QUERY_PAGE_SIZE,
            after_cursor=after_cursor,
            search_term=adp_search_term,
            identifiers_filter=identifiers_filter,
        )
        content = post_query_request(query, "Unexpected error when querying")

        connection = content.get(connection_name)

        if not connection:
            raise RuntimeError(f"Unable to find results for given search query: {adp_search_term}")
        edges = connection.get("edges", [])
        pageInfo = connection.get("pageInfo", [])
        has_next_page = pageInfo.get("hasNextPage", False)
        after_cursor = pageInfo.get("endCursor", "")
        total_count = connection.get("totalCount", [])

        if len(edges) == 0:
            return None

        for edge in edges:
            node = edge.get("node")
            if not node:
                raise RuntimeError("Invalid event format returned from server %s", str(edge))

            if item_type == Log:
                log = _get_log_from_node(node)
                if log:
                    yield typing.cast(_FetchItemType, log)
            elif item_type == TriageEvent:
                event = _get_event_from_node(node)
                if event:
                    yield typing.cast(_FetchItemType, event)
            retrieved_item_count += 1

        _LOGGER.debug("Retrieved %d items out of %d", retrieved_item_count, total_count)
