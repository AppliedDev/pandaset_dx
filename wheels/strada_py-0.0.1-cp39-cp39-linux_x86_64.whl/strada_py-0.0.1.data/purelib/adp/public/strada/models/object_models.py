"""
The StradaClient uses these underlying object classes to represent
data stored in Strada.

1. Collection - these represent a collection of log intervals.
2. LogQueryResult - this represents the results of search query.
3. LogInterval - the base abstract class to represent a segment of time within a log.
4. LogQueryResultItem - these represent the individual intervals of time that are returned in search queries.
5. SupportedPluginSchemaOptions - this object represents the list of schema options you can specify for the export collections plugin with helper methods for setting option values with validation.
6. PluginSchemaOption - this object represents a schema option.
7. Dataset - these represent a group of individual dataset items.
8. Dataset Items - these are objects that make up a dataset.

Refer to the individual class docstrings for more details about
what methods each class support.


Copyright (C) 2022 Applied Intuition, Inc. All rights reserved.
This source code file is distributed under and subject to the LICENSE in
license.txt
"""


from __future__ import annotations

from abc import ABC
from dataclasses import dataclass
from dataclasses import field
from dataclasses import fields
import datetime
import enum
import io
import typing
import zipfile

import pandas as pd
import requests

from adp.public.strada.client_constants import API_ENDPOINTS
from adp.public.strada.client_constants import DEFAULT_COLUMNS_FOR_LOG_SEARCH
from adp.public.strada.models import custom_field_models

if typing.TYPE_CHECKING:
    from adp.public.strada.client import StradaClient

LOG_CUSTOM_FIELD_SOURCE_TYPE_ERROR_MESSAGE = "Custom field must have source type LOG."
LOG_CUSTOM_FIELD_USER_EDITABLE_ERROR_MESSAGE = (
    "Custom field must be editable in order to be edited."
)


def _extract_files_from_remote_zip(url: str, destination_dir: str) -> None:
    r = requests.get(url)
    z = zipfile.ZipFile(io.BytesIO(r.content))
    z.extractall(destination_dir)


@dataclass
class DatasetItem(ABC):
    """Use the `get_dataset` method to get a `Dataset` object which contains DatasetItem objects.

    Args:
        client (StradaClient): An API client that is connected
                                        to a cloud Strada instance.
        log_uuid (str):
        instantaneous_timestamp_ms (int):
        uuid (str):

    Public Methods:
    - export
    """

    client: StradaClient
    log_uuid: str
    instantaneous_timestamp_ms: int
    uuid: str

    def export(self, destination_dir: typing.Optional[str] = None) -> str:
        """Export this dataset item.

        Args:
            destination_dir (str, optional): Local directory to export the items into. If not specified,
            the contents will not be exported to your local machine, but the returned url can be used
            to access the exported data.

        Returns:
            str: The download url to the exported content.
        """
        request = {"dataset_identifier": {"dataset_items": {"dataset_item_uuids": [self.uuid]}}}

        content = self.client.post_request(API_ENDPOINTS.EXPORT_DATASET_OBJECTS, request)
        assert content is not None
        print(f"Dataset item is exported to: {content['downloadUrl']}")

        if destination_dir:
            _extract_files_from_remote_zip(content["downloadUrl"], destination_dir)
            print(f"Dataset item is saved to {destination_dir}")

        assert isinstance(content["downloadUrl"], str)
        return content["downloadUrl"]


@dataclass
class LogInterval(ABC):
    """Abstract Strada Log Interval Object

    [#tags] Public

    Args:
        client (StradaClient): An API client that is connected
                                        to a cloud Strada instance.
        log_uuid (str): The UUID of the parent log.
        instantaneous_timestamp_ms (float): The milliseconds into the log when the event happens.
        start_timestamp_ms (float): The milliseconds into the log when the event starts.
        end_timestamp_ms (float): The milliseconds into the log when the event ends.
        uuid (str): The unique identifier of the interval.
        host_url (str): The host URL the Strada Client connects to.

    Public Methods:
    - link
    - export
    """

    client: StradaClient
    log_uuid: str
    instantaneous_timestamp_ms: int
    start_timestamp_ms: int
    end_timestamp_ms: int
    uuid: str
    """The base URL of the Strada instance, e.g. https://myStradaInstance.applied.dev"""
    host_url: str

    @property
    def link(self) -> str:
        """
        [#tags] Public

        Returns:
            str: The playback link associated with the given log interval.
        """
        return "{}/strada/library/drives/{}/playback&currentTime={}&snippetStart={}&snippetEnd={}".format(
            self.host_url,
            self.log_uuid,
            str(self.instantaneous_timestamp_ms / 1000.0),
            str(self.start_timestamp_ms / 1000.0),
            str(self.end_timestamp_ms / 1000.0),
        )

    def export(self, plugin_options: typing.List[PluginSchemaOption] = []) -> str:
        """Export a LogInterval object based on specified plugin options.

        [#tags] Public

        Args:
            plugin_options (typing.List[PluginSchemaOption]): The list of plugin options to apply to the LogInterval item

        Returns:
            str: The URL of the exported LogInterval object.
        """

        request = {
            "options": [option.to_request_object() for option in plugin_options],
            "event_details": [
                {
                    "drive_uuid": self.log_uuid,
                    "event_time_ms": self.instantaneous_timestamp_ms,
                    "event_start_time_ms": self.start_timestamp_ms,
                    "event_end_time_ms": self.end_timestamp_ms,
                }
            ],
        }

        content = self.client.post_request(API_ENDPOINTS.EXPORT_LOG_INTERVAL, request)
        assert content is not None
        print(f"Log interval is exported to: {content['url']}")
        assert isinstance(content["url"], str)
        return content["url"]


@dataclass
class LogQueryResultItem(LogInterval):
    """Strada Log Query Result Item. Inherits from the abstract LogInterval class.

    [#tags] Public

    Args:
        data_points: typing.Dict[str, str]: The data points that were queried in the original
                                        search query.

    Public Methods:
    """

    data_points: typing.Dict[str, str]


class LogPath(typing.NamedTuple):
    """
    The log path of a log.

    [#tags] Public
    """

    value: str


@dataclass
class Log(ABC):
    """Strada Ingested and Queryable Log Object.

    [#tags] Public

    Args:
        uuid (str): The UUID of the log.
        log_path (str | None, optional): The log path of the log.
        simulation_run_id (int): The simulation run ID of the log.
        created_at (datetime): The time the log object was created (within ADP).
        start_time (datetime | None, optional): The time the log started (in the real world).
        vehicle_name (str | None, optional): The name of the vehicle associated with the log. E.g. "vehicle1".
        tags (list[str], optional): The tags associated with the log. E.g. ["tag1", "tag2"]

    Public Methods:
    """

    uuid: str
    simulation_run_id: int
    created_at: datetime.datetime
    log_path: str | None = None
    # If the log has not yet been post-processed,
    # then start_time could be None.
    start_time: datetime.datetime | None = None
    vehicle_name: str | None = None
    tags: list[str] = field(default_factory=list)
    custom_fields: list[custom_field_models.CustomField] = field(default_factory=list)


@dataclass
class LogEditingConfig:
    """
    LogEditingConfig object.

    Args:
        custom_field (CustomField): If the specified custom field does not exist on the log,
            add a new custom field name, value pair. If the custom field does
            already exist on the log, overwrite it with the new value specified.

    Public Methods:
    """

    custom_field: custom_field_models.CustomField | None = None

    def __init__(self, custom_field: custom_field_models.CustomField | None) -> None:
        if custom_field:
            if custom_field.source_type != custom_field_models.SourceType.LOG:
                raise ValueError("Custom field must have source type LOG.")
            if not custom_field.is_user_editable:
                raise ValueError("Custom field must be editable in order to be edited.")

            self.custom_field = custom_field


@dataclass
class TaxonomyAttributeValue:
    string_value: str | None = None
    int_value: int | None = None
    float_value: float | None = None
    bool_value: bool | None = None

    @staticmethod
    def from_value(value: str | int | float | bool) -> TaxonomyAttributeValue:
        if isinstance(value, str):
            return TaxonomyAttributeValue(string_value=value)
        elif isinstance(value, int):
            return TaxonomyAttributeValue(int_value=value)
        elif isinstance(value, float):
            return TaxonomyAttributeValue(float_value=value)
        elif isinstance(value, bool):
            return TaxonomyAttributeValue(bool_value=value)
        else:
            raise ValueError(
                f"Invalid value provided for TaxonomyAttributeValue: {value}. Value must be of type str, int, float, or bool."
            )

    def asdict(self) -> dict[str, typing.Any]:
        return {
            field.name: getattr(self, field.name)
            for field in fields(self)
            if getattr(self, field.name) is not None
        }


@dataclass
class TaxonomyUpdate:
    node_uuid: str
    values: list[TaxonomyAttributeValue]


@dataclass
class LogQueryResult:
    """Strada Log Query Result Object

    [#tags] Public

    Args:
        results (LogQueryResultItem[]): A list of LogQueryResultItem objects representing
                    Explore page query results.
        status (str): The status of the query. Expected to be successful.

    Public Methods:
    - as_dataframe
    """

    # We use sequence here for proper type checking of parent
    # and base class. See https://github.com/microsoft/pylance-release/issues/955.
    results: typing.Sequence[LogQueryResultItem]
    status: str

    def __init__(self, results: typing.Sequence[LogQueryResultItem], status: str):
        self.results = results
        self.status = status
        self._df = None

    def as_dataframe(self) -> pd.DataFrame:
        """Retrieve the query results as a Pandas dataframe.

        All dataframes will have the following columns for each query result:
        - Log UUID
        - Event timestamp - when searching with Default Time Window, this is the first tick in the interval where the query filter is true
        - Interval start time (in the log)
        - Interval end time

        [#tags] Public

        Returns:
            pd.DataFrame: A Pandas dataframe representing the query results.

        """
        if self._df is None:
            dataframe_rows = []
            for result in self.results:
                row = [
                    # Must match DEFAULT_COLUMNS_FOR_LOG_SEARCH
                    result.log_uuid,
                    result.instantaneous_timestamp_ms,
                    result.start_timestamp_ms,
                    result.end_timestamp_ms,
                ]
                for value in result.data_points.values():
                    row.append(value)
                dataframe_rows.append(row)

            self._df = pd.DataFrame(
                dataframe_rows,
                columns=DEFAULT_COLUMNS_FOR_LOG_SEARCH + list(self.results[0].data_points.keys()),
            )
        return self._df


@dataclass
class Collection:
    """
    Strada Collection Object.

    Args:
        client (StradaClient): An API client that is connected to a cloud Strada instance.
        uuid (str): The uuid of the collection.
        name (str): The name of the collection.
        id (int): The id of the collection.
        events (list[LogInterval]): A list of LogInterval objects representing
                    what is inside the Collection.

    Public Methods:
    - events
    - num_events
    - add_events
    - add_events_from_query
    - export_events
    """

    client: StradaClient
    uuid: str | None
    id: int | None
    name: str | None
    _num_events: int  # Internal metadata tracking the number of events, only used when the events data is not loaded.
    _events: typing.Optional[typing.Sequence[LogInterval]]

    def __init__(
        self,
        client: StradaClient,
        uuid: str | None,
        id: int | None,
        name: str | None,
        num_events: int,
        events: typing.Optional[typing.Sequence[LogInterval]] = None,
    ):
        self.client = client
        self.uuid = uuid
        self.id = id
        self.name = name
        self._events = events
        self._num_events = num_events

    @property
    def events(self) -> typing.Optional[typing.Sequence[LogInterval]]:
        """
        Returns the list of all events in the collection.

        [#tags] Public

        Returns:
            list[LogInterval]: A list of Strada log intervals.
        """
        if self._events is None:
            assert self.id is not None
            result = self.client.get_collection_by_id(self.id)
            self._num_events = result.num_events
            self._events = result.events
            self.name = result.name
        return self._events

    @property
    def num_events(self) -> int:
        """
        Returns the number of events in the collection based on the time it was last loaded.

        [#tags] Public

        Returns:
            int: The number of events in the collection.
        """
        if self._events is None:
            return self._num_events
        return len(self._events)

    def add_events(self, events: typing.Sequence[LogInterval]) -> Collection:
        """Add any list of log intervals to the Collection.

        [#tags] Public

        Args:
            events (list[LogInterval]): A list of LogInterval objects representing
                                                what is inside the Collection.

        Returns:
            Collection: The updated collection metadata with uploaded events.
        """
        return self.client.add_events_to_collection(self, events)

    def add_events_from_query(self, query_result: typing.Type[LogQueryResult]) -> Collection:
        """Add any query result to the collection.

        [#tags] Public

        Args:
            query_result (LogQueryResult): A Strada LogQueryResult object
                                                that is the result of running query_logs.

        Returns:
            Collection: The updated collection metadata with uploaded events.
        """
        return self.add_events(query_result.results)

    def export_events(
        self, export_schemas: typing.Optional[SupportedPluginSchemaOptions] = None
    ) -> str:
        """Export events in this collection.

        [#tags] Public

        Args:
            export_schemas (SupportedPluginSchemaOptions): The export schema options.
        """
        plugin_options = export_schemas.to_request_objects() if export_schemas else None
        request: typing.Dict[str, typing.Any] = {"id": self.id}
        if plugin_options:
            request["options"] = plugin_options
        content = self.client.post_request(API_ENDPOINTS.EXPORT_COLLECTION, request)
        assert content is not None
        print(f"Collection is exported to: {content['url']}")
        return str(content["url"])


class Dataset:
    """Strada Dataset Object. Use the `get_dataset` method to get this object.

    Public Methods:
    - export_items
    """

    client: StradaClient
    name: str
    # Any object that is a child of the abstract LogInterval class.
    items: typing.List[DatasetItem]

    def __init__(
        self,
        client: StradaClient,
        name: str,
        items: typing.List[DatasetItem],
    ):
        """
        [#tags] Public

        Args:
            client (StradaClient): An API client that is connected
                                            to a cloud Strada instance.
            name (str): The name of the dataset.

            items (DatasetItem[]): A list of DatasetItems representing individual
                        frames or instantaneous items.
        """
        self.client = client
        self.name = name
        self.items = items

    def export_items(
        self,
        items: typing.Optional[typing.List[DatasetItem]],
        destination_dir: typing.Optional[str] = None,
    ) -> str:
        """Export dataset items.

        [#tags] Public

        Args:
            items (DatasetItem): A list of items to export.
            destination_dir (str): A path to export the individual items to.
        """
        # TODO(172745): This method should not take in items as a parameter.
        request: dict[str, dict] = {}

        if items:
            request["dataset_identifier"] = {
                "dataset_items": {"dataset_item_uuids": [item.uuid for item in items]}
            }

        else:
            request["dataset_identifier"] = {
                "item_datasets": {"selector_metadata": [{"name": self.name}]}
            }

        content = self.client.post_request(API_ENDPOINTS.EXPORT_DATASET_OBJECTS, request)
        assert content is not None
        print(f"Dataset item is exported to: {content['downloadUrl']}")

        if destination_dir:
            _extract_files_from_remote_zip(content["downloadUrl"], destination_dir)
            print(f"Dataset item is saved to {destination_dir}")

        assert isinstance(content["downloadUrl"], str)
        return content["downloadUrl"]


class PluginSchemaOptionType(enum.Enum):
    FLOAT = "floatValue"
    MULTI_SELECT = "multiSelect"
    STRING = "stringValue"


@dataclass
class PluginSchemaOption:
    """
    A Strada Plugin Schema Object

    Args:
        name (str): The name of the schema option.
        type (PluginSchemaOptionType): The schema type.
        multiselect_options (Optional[List[str]]): The list of options for multiselect. This is set by the get_supported_collection_export_schemas call.
        value (Optional[str]): The value of the schema option. Set this to a value you want to call the plugin with for this schema option. The original value is the default value.

    """

    _name: str
    _type: PluginSchemaOptionType
    _multiselect_options: typing.List[str]
    _value: typing.Optional[float | str | typing.List[str]]

    def __init__(
        self,
        name: str,
        type: PluginSchemaOptionType,
        multiselect_options: typing.List[str] = [],
        value: typing.Optional[float | str | typing.List[str]] = None,
    ):
        self._name = name
        self._type = type
        self._multiselect_options = multiselect_options
        self._value = value

    @property
    def name(self) -> str:
        return self._name

    @property
    def type(self) -> PluginSchemaOptionType:
        return self._type

    @property
    def value(self) -> typing.Optional[float | str | typing.List[str]]:
        return self._value

    @property
    def multiselect_options(self) -> typing.Optional[typing.List[str]]:
        return self._multiselect_options

    def set_value(self, value: str | float | int | typing.List[str]) -> None:
        # Ensure that the value is set properly
        if self._type == PluginSchemaOptionType.FLOAT:
            assert isinstance(value, (float, int))
        elif self.type == PluginSchemaOptionType.STRING:
            assert isinstance(value, str)
        elif self.type == PluginSchemaOptionType.MULTI_SELECT:
            assert isinstance(value, typing.List)
            assert set(value).issubset(self._multiselect_options)
        self._value = value

    def to_request_object(
        self,
    ) -> typing.Dict[str, str | float | typing.Dict[str, typing.List[str]]]:
        assert self.value is not None
        request_object: typing.Dict[str, str | float | typing.Dict[str, typing.List[str]]] = {
            "option_name": self.name,
        }
        if self.type == PluginSchemaOptionType.FLOAT:
            assert isinstance(self.value, (float, int))
            request_object["float_value"] = self.value
        elif self.type == PluginSchemaOptionType.STRING:
            assert isinstance(self.value, str)
            request_object["string_value"] = self.value
        elif self.type == PluginSchemaOptionType.MULTI_SELECT:
            assert isinstance(self.value, typing.List)
            request_object["multi_select"] = {"multiselect_options": self.value}
        return request_object


@dataclass
class SupportedPluginSchemaOptions:
    plugin_schema_options: typing.List[PluginSchemaOption]

    def __init__(self, plugin_schemas: typing.List[PluginSchemaOption]):
        self.plugin_schema_options = plugin_schemas

    def set_schema_option_value(
        self, option_name: str, value: str | float | typing.List[str]
    ) -> None:
        """
        Set the value of a schema option for use in calling the plugin.

        Args:
            option_name (str): The name of the plugin schema option to call.
            value (str): The value to set the plugin schema option to.
        """
        selected_plugin = next(
            (plugin for plugin in self.plugin_schema_options if plugin.name == option_name), None
        )
        assert (
            selected_plugin is not None
        ), f"No plugin schema option with the name {option_name} was found."
        selected_plugin.set_value(value)

    def to_request_objects(
        self,
    ) -> typing.List[typing.Dict[str, str | float | typing.Dict[str, typing.List[str]]]]:
        request_objects: typing.List[
            typing.Dict[str, str | float | typing.Dict[str, typing.List[str]]]
        ] = []
        for option in self.plugin_schema_options:
            if option.value is None:
                continue
            request_objects.append(option.to_request_object())
        return request_objects
