from __future__ import annotations

import abc
from dataclasses import dataclass
from dataclasses import field
from enum import Enum
import typing

from adp.public.strada.models.custom_field_models import CustomField
from adp.public.strada.models.triage_models import TriageEvent
from simian.public.proto import plugin_pb2


### Incremental ingestion data objects ###
class IngestChannelType(Enum):
    CUSTOM = 0
    POSE = 1
    MOTION_FEEDBACK = 2
    CONTROLS = 3
    TRIGGER = 4
    ACTORS = 5
    LANE_SENSOR = 6
    TRAFFIC_LIGHTS = 7
    PLANAR_LIDAR = 8
    PLANAR_OCCUPANCY_GRID = 9
    LIDAR = 10
    RADAR = 11
    CAMERA = 12
    TIME = 13
    TRIP_AGENT = 15
    STACK_STATE = 16
    ULTRASOUND = 17
    LOCALIZATION_SENSOR = 18
    FREE_SPACE_SENSOR = 19
    TRAFFIC_LIGHT_BLOCKS = 20
    TRAFFIC_SIGN_SENSOR = 22
    IMU_SENSOR = 23
    WHEEL_SPEED_SENSOR = 24
    OCCLUSION_GRID = 25
    MAP_SENSOR = 26
    TERRAIN_SENSOR = 28
    OPERATOR_OVERRIDE_STATE = 29
    WIND_SENSOR = 30
    POLAR_OBSTACLE_SENSOR = 31
    AGENT_TRAJECTORY_SENSOR = 32
    PERCEPTION_SENSOR = 33
    TRAJECTORY = 34
    ACTORS_2D = 35


class ConversionMethod(Enum):
    UNSPECIFIED = 0
    CUSTOM = 1
    NUMBER_STAT = 2
    BOOLEAN_STAT = 3


class LogAccessRole(Enum):
    OWNER = 1
    EDITOR = 2
    VIEWER = 3
    RESTRICTED_VIEWER = 5


class DefaultLogAccess(Enum):
    NONE = 0
    OWN = 1
    EDIT = 2
    VIEW_ONLY = 3


class ChannelAccessRole(Enum):
    VIEWER = 1


### Strada Ingestion Models ###
@dataclass
class IngestionImageConfig:
    """IngestionImageConfig Object
    Args:
        ingestion_image: The image that should be used to convert this log.
            If configured = True, then this image should correspond with the image configured in the UI.
        ingestion_mode: The ingestion mode that should be used to convert this log.
            The mode of log ingestion which should match an entry in the config.yaml inside the /strada section of the image.
        configured: Whether or not this log has been configured in the UI.
            Set to true if this is pre-configured in the Strada settings page.
    """

    ingestion_image: str
    ingestion_mode: str
    configured: bool = False


@dataclass
class IngestionPathConfig:
    """IngestionPathConfig Object
    Args:
        drive_config_path: The path to the drive config file.
        run_environment_name: The name of the run environment to be used when ingesting the drive. Cloud only.
        workspace: Workspace to source the drive config file from.
    """

    drive_config_path: str
    run_environment_name: str = ""
    workspace: str = ""


@dataclass
class LogSource:
    """LogSource Object
    Args:
        name: The name of the log source.
        path: The path to the log source.
        start_offset_seconds: The seconds of the start offset. This will be converted to seconds and nanoseconds.
    """

    path: str
    name: str = ""
    start_offset_seconds: float = 0


@dataclass
class LogIngestionMetadata:
    """LogIngestionMetadata Object
    Args:
        logs: A list of LogSource objects to be ingested.
        log_name: The name of the drive to be ingested.
        map_key: The map key to be used when ingesting the drive.
        requirement_uuid: The uuid of the requirement this drive is associated with.
        test_cycle_id: The id of the test cycle this drive is associated with.
        custom_fields: A list of custom fields to be added to the drive.
        events: A list of triage events to be added to the drive.
    """

    logs: list[LogSource]
    log_name: str = ""
    map_key: str = ""
    requirement_uuid: str = ""
    test_cycle_id: int = 0
    custom_fields: list[CustomField] = field(default_factory=list)
    events: list[TriageEvent] = field(default_factory=list)


@dataclass
class BuiltInChannelIdentifier:
    name: str
    type: IngestChannelType


@dataclass
class DataPointIdentifier:
    name: str


class ChannelIdentifierFactory:
    @staticmethod
    def from_built_in_channel(name: str, type: IngestChannelType) -> BuiltInChannelIdentifier:
        return BuiltInChannelIdentifier(name, type)

    @staticmethod
    def from_data_point(name: str) -> DataPointIdentifier:
        return DataPointIdentifier(name)


@dataclass
class LogChannelRole:
    channel_identifier: BuiltInChannelIdentifier | DataPointIdentifier
    role: ChannelAccessRole = ChannelAccessRole.VIEWER

    def to_json_dict(self) -> dict:
        channel_dict: dict
        if type(self.channel_identifier) == BuiltInChannelIdentifier:
            channel_dict = {
                "built_in_channel": {
                    "channel": {
                        "name": self.channel_identifier.name,
                        "type": self.channel_identifier.type.value,
                    }
                }
            }
        else:
            channel_dict = {"data_point": {"name": self.channel_identifier.name}}

        return {"role": self.role.value, "channel": channel_dict}


@dataclass
class LogUserRole:
    """
    LogUserRole to describe an individual user and their
    access to a log.

    Args:
        user: A string representing an individual user (i.e. email) or
            a user group.
        role: An enum that describes a user's role for the log.
        channel_roles: A list of channel-level access roles for the user.
    """

    user: str
    role: LogAccessRole
    channel_roles: list[LogChannelRole] | None

    def __init__(
        self, user: str, role: LogAccessRole, channel_roles: list[LogChannelRole] | None = None
    ):
        if role != LogAccessRole.RESTRICTED_VIEWER and channel_roles is not None:
            raise ValueError("You can only specify channel roles for restricted viewers.")

        self.user = user
        self.role = role
        self.channel_roles = channel_roles

    def to_json_dict(self) -> dict:
        log_user_role_dict: dict[str, typing.Any] = {"user": self.user, "role": self.role.value}
        if self.channel_roles:
            log_user_role_dict["channel_roles"] = [
                channel_role.to_json_dict() for channel_role in self.channel_roles
            ]
        return log_user_role_dict


@dataclass
class LogPermissions:
    """
    LogPermissions object to describe access permissions on
    a log.
    """

    user_roles: list[LogUserRole]
    default_access_level: DefaultLogAccess = DefaultLogAccess.NONE

    def to_json_dict(self) -> dict:
        return {
            "user_roles": [user_role.to_json_dict() for user_role in self.user_roles],
            "default_access_level": self.default_access_level.value,
        }


@dataclass
class IngestionParameters:
    """IngestionParameters Object
    Args:
        log_duration_secs: The duration of the drive in seconds.
        include_file_paths: A list of include files to be used when ingesting the drive.
        trailing_yaml: Additional yaml to be appended to the drive config. This will be uploaded to the same workspace.
        sim_flags: Simulation flags that the drive conversion will be run with.
        tenant_name: Tenant whose resources this drive will be run on. Cloud only.
        max_auto_retries: The maximum number of times to retry the ingestion process if it fails.
        log_permissions: Specify permissions on who can access the log. This will only be enforced
            when access controls are enabled.
    """

    log_duration_secs: int
    max_auto_retries: int = 0
    sim_flags: str = ""
    trailing_yaml: str = ""
    tenant_name: str = ""
    include_file_paths: list[str] = field(default_factory=list)
    log_permissions: LogPermissions | None = None
    is_partial: bool = False


@dataclass
class IngestLogsWithModeRequest:
    """IngestLogsWithModeRequest Object
    Args:
        ingestion_image_config: The IngestionImageConfig object to be used when ingesting the drive.
        common_ingestion_metadata: The common ingestion metadata to be used when ingesting the drive.
    """

    ingestion_image_config: IngestionImageConfig
    log_ingestion_metadata: LogIngestionMetadata
    ingestion_parameters: IngestionParameters


@dataclass
class IngestLogsWithPathRequest:
    """IngestLogsWithPathRequest Object
    Args:
        ingestion_path_config: The IngestionPathConfig to be used when ingesting the drive.
        common_ingestion_metadata: The common ingestion metadata to be used when ingesting the drive.

    Public Methods:
    """

    ingestion_path_config: IngestionPathConfig
    log_ingestion_metadata: LogIngestionMetadata
    ingestion_parameters: IngestionParameters


@dataclass
class AbstractIngestChannelRequest(abc.ABC):
    """Common object for all types of ingestion channel requests. This is not meant to
    be instantiated directly. Use IngestChannelRequestFactory to create these objects.
    """

    channel_name: str
    channel_type: IngestChannelType
    conversion_method: ConversionMethod
    extra_data: dict
    external_result_proto: plugin_pb2.FinalizePostprocessResultsResponse


class IngestChannelRequestFactory:
    @staticmethod
    def from_custom(
        channel_name: str, channel_type: IngestChannelType, extra_data: dict = {}
    ) -> CustomIngestChannelRequest:
        """Constructs a CustomIngestChannelRequest object for adding data to log a
           log via a custom Strada ingestion.

        Args:
            channel_name (str): The name of the channel to ingest into the log. This is the identifier
                that will be displayed when viewing the ingested channel.
            channel_type (IngestChannelType): The channel type of the channel to ingest into the log.
            extra_data (dict, optional): Arbitrary data that can be sent to the interface to aid in ingesting this
                additional channel. For example, can be a unique identifier of the channel or can contain
                the remote URI to where the underlying channel data is stored.

        Returns:
            CustomIngestChannelRequest: Object that represents the channel ingestion request with the given
            parameters.
        """
        return CustomIngestChannelRequest(channel_name, channel_type, extra_data)

    @staticmethod
    def from_number_stat(
        channel_name: str, time_series_data: typing.List[typing.Tuple[float, float]] = []
    ) -> NumberStatIngestChannelRequest:
        """Constructs a NumberStatIngestChannelRequest object for adding external numerical
           time-series to a log.

        Args:
            channel_name (str): The name of the channel we want to ingest into the log. This is the identifier
                that will be displayed when viewing the ingested channel.
            time_series_data (typing.List[typing.Tuple[float, float]]): An array of tuples where the first element is
                the offset time and the second value is the numerical float value of the stat. (e.g. `[(0.0, 1.0)]`)

        Returns:
            NumberStatIngestChannelRequest: Object that represents the numerical stat ingestion request with
            the given parameters
        """
        return NumberStatIngestChannelRequest(channel_name, time_series_data)

    @staticmethod
    def from_boolean_stat(
        channel_name: str, time_series_data: typing.List[typing.Tuple[float, bool]] = []
    ) -> BooleanStatIngestChannelRequest:
        """Constructs a BooleanStatIngestChannelRequest object for adding external boolean
           time-series to a log.

        Args:
            channel_name (str): The name of the channel we want to ingest into the log. This is the identifier
                that will be displayed when viewing the ingested channel.
            time_series_data (typing.List[typing.Tuple[float, bool]]): An array of tuples where the first element is the
                offset time and the second value is the boolean float value of the stat. (e.g. `[(0.0, True)]`)

        Returns:
            BooleanStatIngestChannelRequest: Object that represents the boolean stat ingestion request with
            the given parameters
        """
        return BooleanStatIngestChannelRequest(channel_name, time_series_data)


class CustomIngestChannelRequest(AbstractIngestChannelRequest):
    def __init__(
        self,
        channel_name: str,
        channel_type: IngestChannelType,
        extra_data: dict = {},
    ):
        """Constructs a CustomIngestChannelRequest object for adding data to log a
           log via a custom Strada ingestion.

        Args:
            channel_name (str): The name of the channel to ingest into the log. This is the identifier
                that will be displayed when viewing the ingested channel.
            channel_type (IngestChannelType): The channel type of the channel to ingest into the log.
            extra_data (dict, optional): Arbitrary data that can be sent to the interface to aid in ingesting this
                additional channel. For example, can be a unique identifier of the channel or can contain
                the remote URI to where the underlying channel data is stored.

        Returns:
            CustomIngestChannelRequest: Object that represents the channel ingestion request with the given
            parameters.
        """

        self.channel_name = channel_name
        self.channel_type = channel_type
        self.extra_data = extra_data
        self.conversion_method = ConversionMethod.CUSTOM


class NumberStatIngestChannelRequest(AbstractIngestChannelRequest):
    def __init__(
        self, channel_name: str, number_stat: typing.List[typing.Tuple[float, float]] = []
    ):
        """Constructs a NumberStatIngestChannelRequest object for adding external numerical
           time-series to a log.

        Args:
            channel_name (str): The name of the channel we want to ingest into the log. This is the identifier
                that will be displayed when viewing the ingested channel.
            time_series_data (typing.List[typing.Tuple[float, float]]): An array of tuples where the first element is
                the offset time and the second value is the numerical float value of the stat. (e.g. `[(0.0, 1.0)]`)

        Returns:
            NumberStatIngestChannelRequest: Object that represents the numerical stat ingestion request with
            the given parameters
        """
        self.external_result_proto = plugin_pb2.FinalizePostprocessResultsResponse()
        self.conversion_method = ConversionMethod.NUMBER_STAT

        sim_times, values = zip(*number_stat)
        number_stat_proto = self.external_result_proto.number_stats.add()
        number_stat_proto.name = channel_name
        number_stat_proto.values.extend(values)
        number_stat_proto.sim_times.extend(sim_times)


class BooleanStatIngestChannelRequest(AbstractIngestChannelRequest):
    def __init__(
        self, channel_name: str, boolean_stat: typing.List[typing.Tuple[float, bool]] = []
    ):
        """Constructs a BooleanStatIngestChannelRequest object for adding external boolean
           time-series to a log.

        Args:
            channel_name (str): The name of the channel we want to ingest into the log. This is the identifier
                that will be displayed when viewing the ingested channel.
            time_series_data (typing.List[typing.Tuple[float, bool]]): An array of tuples where the first element is the
                offset time and the second value is the boolean float value of the stat. (e.g. `[(0.0, True)]`)

        Returns:
            BooleanStatIngestChannelRequest: Object that represents the boolean stat ingestion request with
            the given parameters
        """
        self.external_result_proto = plugin_pb2.FinalizePostprocessResultsResponse()
        self.conversion_method = ConversionMethod.BOOLEAN_STAT

        sim_times, values = zip(*boolean_stat)
        boolean_stat_proto = self.external_result_proto.boolean_stats.add()
        boolean_stat_proto.name = channel_name
        boolean_stat_proto.values.extend(values)
        boolean_stat_proto.sim_times.extend(sim_times)
