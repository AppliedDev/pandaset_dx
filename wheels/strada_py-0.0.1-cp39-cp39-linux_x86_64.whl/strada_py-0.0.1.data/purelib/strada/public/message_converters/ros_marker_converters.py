"""
Convert common ros types into applied protos.

Can convert into Drawings (Marker, ImageMarker) or perception channels such as Actors.
"""
from __future__ import annotations

from typing import Any, List

from simian.public.proto import drawing_pb2

# See: http://docs.ros.org/en/noetic/api/visualization_msgs/html/msg/Marker.html
MARKER_TYPE_TO_DRAWING_TYPE = {
    2: drawing_pb2.Drawing.sphere,
    1: drawing_pb2.Drawing.box,
    0: drawing_pb2.Drawing.ray,
}


def _marker_to_drawing(_marker: Any) -> drawing_pb2.Drawing:
    # TODO(def-ai): Finish function.
    return drawing_pb2.Drawing()


def marker_array_to_drawing(marker_array: Any) -> List[drawing_pb2.Drawing]:
    drawings = []

    for marker in marker_array.markers:
        drawings.append(_marker_to_drawing(marker))

    return []
