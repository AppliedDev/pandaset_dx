from __future__ import annotations

import logging
import time
from typing import Any

import cv2
import numpy as np
import turbojpeg

from simian.public.proto import sensor_model_pb2

logger = logging.getLogger("ImageConversionFunctions")


try:
    turbo_jpeg = turbojpeg.TurboJPEG()
except Exception as e:  # noqa: F841
    logger.exception("Could not initialize turbo jpeg. Falling back to cv2")
    turbo_jpeg = None


def _encode_image(img: np.ndarray) -> bytes:
    """
    Encode an image
    1. Use TurboJpeg for speed if available.
    2. Fallback to cv2.encode if not.
    """
    encode_start = time.time()
    if turbo_jpeg:
        im_bytes = turbo_jpeg.encode(img)
    else:
        # TODO(def-ai): fix this.
        # im_bytes = cv2.imencode(img)
        raise NotImplementedError("Need to implement non turbojpeg encoding")

    logger.debug("Took %ss to encode img" % (time.time() - encode_start))  # noqa: G002
    return im_bytes  # type: ignore[no-any-return]


def CompressedImage_to_CameraImage(msg: Any) -> sensor_model_pb2.SensorOutput.CameraImage:
    """
    TODO(def): Add resizing, bgr, timing, etc functionality.
    May need to move this into an image converter class that takes in configuration parameters.
    """
    output_proto = sensor_model_pb2.SensorOutput.CameraImage()

    np_arr = np.frombuffer(msg.data, dtype=np.uint8)
    ### 2. Decode & re-encode ros message
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    img_bytes = _encode_image(img)

    output_proto.image.image_bytes = img_bytes
    output_proto.image.format = sensor_model_pb2.Image.JPEG

    height, width, _ = img.shape
    output_proto.image_shape.height = height
    output_proto.image_shape.width = width

    return output_proto
