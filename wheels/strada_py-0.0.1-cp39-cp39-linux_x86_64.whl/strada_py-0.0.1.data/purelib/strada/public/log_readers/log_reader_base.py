from __future__ import annotations

import abc
import dataclasses
import datetime
from pathlib import Path
from typing import Any, Optional, Union

from simian.public.proto.v2 import io_pb2

LogPath = Union[str, Path]


@dataclasses.dataclass
class LogReadType:
    topic: str
    message: Any
    epoch_timestamp: datetime.datetime


class LogReaderBase(abc.ABC):
    """
    A log reader should efficiently read data out of a single file and
    pull relevant information into memory.
    """

    def __init__(self, configuration: dict):
        raise NotImplementedError()

    def open(self, path: LogPath, log_open_options: io_pb2.LogOpenOptions) -> io_pb2.LogOpenOutput:
        raise NotImplementedError()

    def close(self, log_close_options: io_pb2.LogCloseOptions) -> None:
        raise NotImplementedError()

    def read_message(self) -> Optional[LogReadType]:
        """
        Read a single message and return it.
        """
        raise NotImplementedError()

    def __iter__(self) -> LogReaderBase:
        return self

    def __next__(self) -> LogReadType:
        msg = self.read_message()

        if msg is None:
            raise StopIteration

        return msg
