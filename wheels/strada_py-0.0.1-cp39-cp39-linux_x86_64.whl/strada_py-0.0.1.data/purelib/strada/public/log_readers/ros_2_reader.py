from __future__ import annotations

from typing import List

from strada.public.log_readers import log_reader_base


class Ros2Reader(log_reader_base.LogReaderBase):
    def __init__(self, paths: List[log_reader_base.LogPath]) -> None:
        self._paths = paths

    def read_message(self) -> log_reader_base.LogReadType:
        # todo - pull code from variety of repos
        pass
