from __future__ import annotations

from dataclasses import asdict
from dataclasses import dataclass
from dataclasses import field
import datetime
import typing

from adp.public.strada.models import custom_field_models

EVENT_EDITING_FIELD_DISPLAY_NAME_TO_PROTO_FIELD: dict[str, str] = {
    "name_to_set": "set_name",
    "assignee_to_add": "add_assignee",
    "assignee_to_remove": "remove_assignee",
    "root_causes_to_add": "add_root_causes",
    "root_causes_to_remove": "remove_root_causes",
    "customer_issue_ids_to_add": "add_customer_issue_ids",
    "customer_issue_ids_to_remove": "remove_customer_issue_ids",
    "tags_to_add": "add_tags",
    "tags_to_remove": "remove_tags",
    "status_to_add": "add_status",
    "status_to_remove": "remove_status",
    "custom_field_to_add": "add_custom_field",
    "custom_field_to_remove": "delete_custom_field",
    "close_events": "close_events",
    "reopen_events": "reopen_events",
    "delete_events": "delete_events",
}

INVALID_ASSIGNEE_ERROR_MESSAGE = "Cannot specify both an assignee to add and an assignee to remove."
INVALID_EVENT_STATE_ERROR_MESSAGE = (
    "Cannot specify more than one: close_events, reopen_events, delete_events."
)
INVALID_STATUS_ERROR_MESSAGE = "Cannot specify both a status to add and a status to remove."
INVALID_CUSTOM_FIELD_ERROR_MESSAGE = (
    "Cannot specify both a custom field to add and a custom field to remove."
)
INVALID_TRIAGE_CUSTOM_FIELD_SOURCE_TYPE_ERROR_MESSAGE = (
    "The custom field to add/remove must have source type as event."
)


def _get_iso_format_from_seconds(seconds: float) -> str:
    return "{}Z".format(datetime.datetime.utcfromtimestamp(seconds).isoformat())  # noqa: DTZ004


@dataclass
class TriageEventEditingConfig:
    """TriageEventEditingConfig Object. Used for specifying changes to an event.

    [#tags] Public

    Args:
        name_to_set (str): The name to set.
        assignee_to_add (str): The assignee to add.
        assignee_to_remove (str): The assignee to remove.
        root_causes_to_add (list[str]): The root causes to add.
        root_causes_to_remove (list[str]): The root causes to remove.
        customer_issue_ids_to_add (list[str]): The customer issue ids to add.
        customer_issue_ids_to_remove (list[str]): The customer issue ids to remove.
        tags_to_add (list[str]): The tags to add.
        tags_to_remove (list[str]): The tags to remove.
        status_to_add (str): The status to add.
        status_to_remove (str): The status to remove.
        custom_field_to_add (custom_field_models.CustomField): The custom field to add.
        custom_field_to_remove (custom_field_models.CustomField): The custom field to remove.
        close_events (bool): Whether to close events.
        reopen_events (bool): Whether to reopen events.
        delete_events (bool): Whether to delete events.

    Public Methods:
    - validate
    """

    name_to_set: str | None = None
    assignee_to_add: str | None = None
    assignee_to_remove: str | None = None
    root_causes_to_add: list[str] | None = None
    root_causes_to_remove: list[str] | None = None
    customer_issue_ids_to_add: list[str] | None = None
    customer_issue_ids_to_remove: list[str] | None = None
    tags_to_add: list[str] | None = None
    tags_to_remove: list[str] | None = None
    status_to_add: str | None = None
    status_to_remove: str | None = None
    custom_field_to_add: custom_field_models.CustomField | None = None
    custom_field_to_remove: custom_field_models.CustomField | None = None

    close_events: bool | None = None
    reopen_events: bool | None = None
    delete_events: bool | None = None

    def validate(self) -> str | None:
        """Validate that the edit request doesn't contain conflicting fields.

        Returns:
            str | None: A descriptive string about the conflict if the config is valid, otherwise None.
        """
        if self.assignee_to_add and self.assignee_to_remove:
            return INVALID_ASSIGNEE_ERROR_MESSAGE

        event_actions = [self.close_events, self.reopen_events, self.delete_events]
        if event_actions.count(True) > 1:
            return INVALID_EVENT_STATE_ERROR_MESSAGE

        if self.status_to_add and self.status_to_remove:
            return INVALID_STATUS_ERROR_MESSAGE

        if self.custom_field_to_add and self.custom_field_to_remove:
            return INVALID_CUSTOM_FIELD_ERROR_MESSAGE

        for custom_field in [self.custom_field_to_add, self.custom_field_to_remove]:
            if (
                custom_field
                and not custom_field.source_type == custom_field_models.SourceType.EVENT
            ):
                return INVALID_TRIAGE_CUSTOM_FIELD_SOURCE_TYPE_ERROR_MESSAGE

        # There are no issues so return None.
        return None

    def get_constructed_edit_request(self) -> dict[str, typing.Any]:
        request = {}
        for display_name, proto_field in EVENT_EDITING_FIELD_DISPLAY_NAME_TO_PROTO_FIELD.items():
            value = getattr(self, display_name)
            if value is None:
                continue

            if display_name == "custom_field_to_add" or display_name == "custom_field_to_remove":
                if not value.source_type == custom_field_models.SourceType.EVENT:
                    raise ValueError(INVALID_TRIAGE_CUSTOM_FIELD_SOURCE_TYPE_ERROR_MESSAGE)

                custom_field_dict = value.to_json_dict()
                del custom_field_dict["user_editable"]
                if isinstance(value, custom_field_models.RepeatedStringCustomField):
                    custom_field_dict["repeated_string"] = custom_field_dict[
                        "repeated_string_value"
                    ]
                    del custom_field_dict["repeated_string_value"]

                request[proto_field] = custom_field_dict
            else:
                request[proto_field] = getattr(self, display_name)
        return request


@dataclass
class TriageEventActions:
    auto_resim: bool = False
    extract_resim_scenario: bool = False


@dataclass
class EventRelativeOffset:
    """EventRelativeOffset Object. Used for specifying the relative time of an event.

    [#tags] Public

    Args:
        time_secs (float): The time of the event relative to the start of the log.
        start_time_secs (float): The start time of the event relative to the start of the log.
        end_time_secs (float): The end time of the event relative to the end of the log.
    """

    time_secs: float
    start_time_secs: float
    end_time_secs: float


class EventUUID(typing.NamedTuple):
    """
    The uuid of an event.
    """

    value: str


@dataclass
class TriageEvent:
    """TriageEvent Object. Can be fetched, edited, or created via SDK.

    [#tags] Public

    Args:
        uuid (str): The uuid of the event.
        relative_offset (EventRelativeOffset): The relative time of the event.
        from_disengagement (bool): Whether the event was created from a disengagement.
        reason (str): The reason for the event.
        location (Location): The location of the event.
        assignee_email (str): The email of the assignee.
        root_causes (list[str]): The root causes of the event.
        custom_fields (list[CustomField]): The custom fields of the event.
        driver_comment (str): The driver comment of the event.
        tags (list[str]): The tags of the event.
        snippet_log_path (str): The snippet log path of the event.
        key (str): Short, human-readable identifier key used to generate a [simple identifier](https://home.applied.co/manual/data_explorer/latest/#/triage/creating_triage_events/creating_triage_events?id=event-simple-string-identifier)
        metadata (dict[str, str]): Non-queryable key-value data associated with the event.

    Public Methods:
    - to_json_dict
    - create_from_relative_time
    - create_from_absolute_time
    """

    @dataclass
    class Location:
        lat: float | None = None
        lng: float | None = None

    uuid: str
    relative_offset: EventRelativeOffset
    from_disengagement: bool = False
    reason: str | None = None
    location: Location | None = None
    assignee_email: str | None = None
    root_causes: list[str] = field(default_factory=list)
    custom_fields: list[custom_field_models.CustomField] = field(default_factory=list)
    driver_comment: str | None = None
    tags: list[str] = field(default_factory=list)
    snippet_log_path: str | None = None
    key: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    def to_json_dict(self) -> dict[str, typing.Any]:
        """Returns the event as a json dict.

        Returns:
            dict[str, typing.Any]: The event info as a json dict.
        """
        event_dict = asdict(self)
        event_custom_fields = [custom_field.to_json_dict() for custom_field in self.custom_fields]
        event_dict["custom_fields"] = event_custom_fields

        relative_time = event_dict["relative_offset"]
        event_dict["time"] = _get_iso_format_from_seconds(relative_time["time_secs"])
        event_dict["start_time"] = _get_iso_format_from_seconds(relative_time["start_time_secs"])
        event_dict["end_time"] = _get_iso_format_from_seconds(relative_time["end_time_secs"])

        del event_dict["relative_offset"]

        return event_dict

    @staticmethod
    def from_args(
        event_uuid: str,
        relative_offset: EventRelativeOffset,
        comment: str | None = None,
        location: TriageEvent.Location | None = None,
        reason: str | None = None,
        custom_field_description: custom_field_models.CustomFieldDescription | None = None,
    ) -> TriageEvent:
        """Create a TriageEvent object.

        Args:
            event_uuid (str): The uuid of the event.
            relative_offset (EventRelativeOffset): The offset of the log to create the event
            comment (str | None, optional): The main operator comment for the event. Defaults to None.
            location (TriageEvent.Location | None, optional): The location of the event. Defaults to None.
            reason (str | None, optional): The reason for the event. Defaults to None.
            custom_field_description (custom_field_models.CustomFieldDescription | None, optional): Custom fields for the event. Defaults to None.

        Returns:
            TriageEvent: The triage event object that can be added to data explorer via `add_events_to_log`.
        """
        event = TriageEvent(
            uuid=event_uuid,
            relative_offset=relative_offset,
            driver_comment=comment,
            reason=reason,
            location=location,
        )

        if custom_field_description:
            event.custom_fields.extend(
                custom_field_description.get_all_custom_fields(custom_field_models.SourceType.EVENT)
            )

        return event

    @staticmethod
    def create_from_relative_time(
        event_uuid: str,
        relative_time_of_event: float,
        default_event_window: float,
        comment: str | None = None,
        lat: float | None = None,
        lng: float | None = None,
        reason: str | None = None,
        custom_field_description: custom_field_models.CustomFieldDescription | None = None,
    ) -> TriageEvent:
        """Create triage event from offset relative to the log.

        Args:
            event_uuid (str): The uuid of the event.
            relative_time_of_event (float): The number of seconds relative to the epoch time of the start of the log.
            default_event_window (float): The number of seconds to look before and after the event time when creating the event window.
            comment (str | None, optional): The main operator comment for the event. Defaults to None.
            lat (float | None, optional): The latitude location of the event. Defaults to None.
            lng (float | None, optional): The longitude location of the event. Defaults to None.
            reason (str | None, optional): The reason for the event. Defaults to None.
            custom_field_description (custom_field_models.CustomFieldDescription | None, optional): Custom fields for the event. Defaults to None.

        Returns:
            TriageEvent: The triage event object that can be added to data explorer via `add_events_to_log`.
        """
        start_time = max(0, relative_time_of_event - default_event_window)
        end_time = relative_time_of_event + default_event_window

        return TriageEvent.from_args(
            event_uuid=event_uuid,
            relative_offset=EventRelativeOffset(
                time_secs=relative_time_of_event, start_time_secs=start_time, end_time_secs=end_time
            ),
            comment=comment,
            location=TriageEvent.Location(lat=lat, lng=lng),
            reason=reason,
            custom_field_description=custom_field_description,
        )

    @staticmethod
    def create_from_absolute_time(
        event_uuid: str,
        event_time_utc: datetime.datetime,
        log_start_time_utc: datetime.datetime,
        default_event_window: float,
        comment: str | None = None,
        lat: float | None = None,
        lng: float | None = None,
        reason: str | None = None,
        custom_field_description: custom_field_models.CustomFieldDescription | None = None,
    ) -> TriageEvent:
        """Create triage event from absolute epoch time.

        Args:
            event_uuid (str): The uuid of the event.
            event_time_utc (datetime.datetime): The epoch time of the event.
            log_start_time_utc (datetime.datetime): The epoch time of the start of the log. This can be obtained from `get_latest_drive_for_log`.
            default_event_window (float): The number of seconds to look before and after the event time when creating the event window.
            comment (str | None, optional): The main operator comment for the event. Defaults to None.
            lat (float | None, optional): The latitude location of the event. Defaults to None.
            lng (float | None, optional): The longitude location of the event. Defaults to None.
            reason (str | None, optional): The reason for the event. Defaults to None.
            custom_field_description (custom_field_models.CustomFieldDescription | None, optional): Custom fields for the event. Defaults to None.

        Returns:
            TriageEvent: The triage event object that can be added to data explorer via `add_events_to_log`.
        """
        relative_time_of_event = (event_time_utc - log_start_time_utc).total_seconds()

        start_time = max(0, relative_time_of_event - default_event_window)
        end_time = relative_time_of_event + default_event_window

        return TriageEvent.from_args(
            event_uuid=event_uuid,
            relative_offset=EventRelativeOffset(
                time_secs=relative_time_of_event, start_time_secs=start_time, end_time_secs=end_time
            ),
            comment=comment,
            location=TriageEvent.Location(lat=lat, lng=lng),
            reason=reason,
            custom_field_description=custom_field_description,
        )
