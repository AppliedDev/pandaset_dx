"""
The StradaClient class is used to interact with a cloud
or local deployment of Strada.


Copyright (C) 2022 Applied Intuition, Inc. All rights reserved.
This source code file is distributed under and subject to the LICENSE in
license.txt
"""

from __future__ import annotations

from datetime import datetime
import enum
import json
import logging
import time
import typing

from dateutil import parser
from google.protobuf import json_format
import pandas as pd

from adp.public.common.sdk_errors import ADPBugError
from adp.public.common.sdk_errors import ADPSDKError
from adp.public.common.sdk_helpers import SdkBase
from adp.public.strada.client_constants import API_ENDPOINTS
from adp.public.strada.client_constants import ERROR_MESSAGES
from adp.public.strada.client_constants import EXPORT_COLLECTIONS_PARALLELIZATION_MODE
from adp.public.strada.client_constants import MAX_EVENT_QUERY_RESULTS
from adp.public.strada.client_constants import QUERY_STRINGS
from adp.public.strada.graphql_fetch import iter_fetch_items
from adp.public.strada.models.collection_models import CollectionUserRole
from adp.public.strada.models.collection_models import DefaultCollectionAccess
from adp.public.strada.models.export_collection_models import ExportCollectionJob
from adp.public.strada.models.export_collection_models import ExportCollectionJobStatus
from adp.public.strada.models.export_collection_models import JobStatus
from adp.public.strada.models.ingestion_models import AbstractIngestChannelRequest
from adp.public.strada.models.ingestion_models import ConversionMethod
from adp.public.strada.models.ingestion_models import DefaultLogAccess
from adp.public.strada.models.ingestion_models import IngestionParameters
from adp.public.strada.models.ingestion_models import IngestLogsWithModeRequest
from adp.public.strada.models.ingestion_models import IngestLogsWithPathRequest
from adp.public.strada.models.ingestion_models import LogIngestionMetadata
from adp.public.strada.models.ingestion_models import LogUserRole
from adp.public.strada.models.object_models import Collection
from adp.public.strada.models.object_models import Dataset
from adp.public.strada.models.object_models import DatasetItem
from adp.public.strada.models.object_models import Log
from adp.public.strada.models.object_models import LogEditingConfig
from adp.public.strada.models.object_models import LogInterval
from adp.public.strada.models.object_models import LogPath
from adp.public.strada.models.object_models import LogQueryResult
from adp.public.strada.models.object_models import LogQueryResultItem
from adp.public.strada.models.object_models import PluginSchemaOption
from adp.public.strada.models.object_models import PluginSchemaOptionType
from adp.public.strada.models.object_models import SupportedPluginSchemaOptions
from adp.public.strada.models.object_models import TaxonomyUpdate
from adp.public.strada.models.parallelized_export_collection_models import (
    ParallelizedExportCollectionJob,
)
from adp.public.strada.models.parallelized_export_collection_models import (
    ParallelizedExportCollectionJobStatus,
)
from adp.public.strada.models.parallelized_export_collection_models import (
    ParallelizedExportCollectionSubjob,
)
from adp.public.strada.models.parallelized_export_collection_models import (
    ParallelizedExportCollectionSubjobExecution,
)
from adp.public.strada.models.plugin_executor_models import PluginExecutor
from adp.public.strada.models.plugin_queue_models import PluginQueue
from adp.public.strada.models.triage_models import EventUUID
from adp.public.strada.models.triage_models import TriageEvent
from adp.public.strada.models.triage_models import TriageEventEditingConfig
from simian.public.proto import log_search_query_pb2
from simian.public.proto import plugin_pb2

if typing.TYPE_CHECKING:
    from adp.public.strada.models.object_models import LogInterval


_LOGGER = logging.getLogger("StradaClient")
_LOGGER.setLevel(logging.INFO)


def _get_metric_names_from_single_result(result: dict) -> list[str]:
    metric_names = []
    for key in result.keys():
        if key.endswith("_val"):
            metric_names.append(key)

    return metric_names


def _get_milliseconds_since_epoch(date: datetime) -> int:
    epoch = datetime.utcfromtimestamp(0)  # noqa: DTZ004
    return int((date - epoch).total_seconds() * 1000.0)


def datetime_from_datetime_string(datetime_str: str) -> datetime:
    return parser.parse(datetime_str)


class LogSearchQueryType(enum.Enum):
    """Enum describing the [type of log search](https://home.applied.co/manual/strada/latest/#/log_querying/query_builder/query_builder?id=query-type) to be executed.

    [#tags] Public
    """

    UNKNOWN_QUERY_TYPE = "UNKNOWN_QUERY_TYPE"
    DEFAULT_TIME_WINDOW = "DEFAULT_TIME_WINDOW"
    EXACT_MATCH = "EXACT_MATCH"


class SearchLanguage(enum.Enum):
    """Enum describing the supported search languages for Data Explorer queries.

    [#tags] Public
    """

    ADP = "ADP"


class SearchFilter:
    """
    Object that represents the search filter(s) for a fetch request.

    [#tags] Public

    Args:
        term (str): The search term in the selected search language.
        language (SearchLanguage, optional): The language of the search term (default: SearchLanguage.ADP).
    """

    def __init__(self, term: str, language: SearchLanguage = SearchLanguage.ADP):
        self.term = term
        self.language = language
        if not isinstance(language, SearchLanguage):
            raise ValueError("Invalid search language")


class StradaClientError(Exception):
    """Strada Client Error"""


class StradaClient(SdkBase[API_ENDPOINTS]):
    """
    This client is used to interact with Strada. It will work for both local and cloud Strada.

    Public Methods
    - __init__
    - query_logs
    - add_events_to_collection
    - create_collection
    - delete_collections
    - list_collections
    - get_collection_by_id
    - get_collection_by_name
    - get_dataset
    - get_queryable_logs
    - get_latest_drive_for_log
    - query_for_event_uuids_using_search_term
    - edit_events_by_uuid
    - add_events_to_log
    - edit_log_metadata_by_log_path
    - ingest_strada_log_with_config_path
    - enqueue_parallelized_export_collections
    - get_parallelized_export_log_collections_by_collection_uuid
    - get_parallelized_export_log_collections_by_export_uuid
    - get_parallelized_export_log_collections_subjob_status
    - rerun_export_log_collections_subjobs
    - update_taxonomy_summary_on_log
    - create_plugin_queue
    - get_plugin_queue
    - update_plugin_queue
    - delete_plugin_queue
    - list_plugin_queues
    """

    def __init__(
        self,
        auth_token: str = "",
        api_endpoint: str = "",
        remote_hostname: str = "",
        is_cloud: bool = True,
    ):
        """
        <!-- This just calls the parent init function. It is duplicated for ease of docs generation -->
        Creates a Base API client with helpers to interact with the local and cloud REST APIs.

        [#tags] Public

        Args:
            auth_token (str): ADP auth token. This token can be found under the
                                profile icon in ADPHome or you can programatically generate a [machine credential](https://home.applied.co/manual/adp/latest/#/integrating_with_adp/machine_authorization/machine_authorization?id=machine-authorization).
            api_endpoint (str): The API base endpoint of the remote simulator.
                                Typically the `{}` in `https://{}/api`.
            remote_hostname (str): The remote hostname pointing to the running ADP instance
                                you are trying to access. Typically the {} in `https://{}/adp/results`.
            is_cloud (bool): Whether the remote hostname is a cloud-based ADP instance or a
                                local-based ADP instance.

        Example:
            from adp.public.strada.client import StradaClient
            strada_api = StradaClient(
                auth_token="my-secret-auth-token",  # Replace with your auth token
                api_endpoint="api.customer.applied.dev",
                remote_hostname="customer.applied.dev",
                is_cloud=True,
            )

        Raises:
            ADPUnavailableError: If client is unable to connect to ADP.
        """
        super().__init__(auth_token, api_endpoint, remote_hostname, is_cloud)

    def _parse_log_query_results(
        self, results: typing.List[typing.Dict]
    ) -> list[LogQueryResultItem]:
        metric_names = _get_metric_names_from_single_result(results[0])
        log_query_result_items: list[LogQueryResultItem] = []
        for result in results:
            data_points = {}
            for name in metric_names:
                # The metric names are returned from the backend as {metric_name}_val.
                # We need to strip the last 4 characters to get the true name.
                data_points[name[:-4]] = result.get(name)

            if "start_time_epoch_ms" in result:
                start_time_epoch_ms = int(result["start_time_epoch_ms"])
            elif "event_start_time_ms" in result:
                start_time_epoch_ms = int(result["event_start_time_ms"])
            else:
                raise ADPBugError("Event start time not found in result")

            if "end_time_epoch_ms" in result:
                end_time_epoch_ms = int(result["end_time_epoch_ms"])
            elif "event_end_time_ms" in result:
                end_time_epoch_ms = int(result["event_end_time_ms"])
            else:
                raise ADPBugError("Event end time not found in result")

            item = LogQueryResultItem(
                self,  # client
                result["uuid"],
                int(result["event_time_epoch_ms"]),
                start_time_epoch_ms,
                end_time_epoch_ms,
                result["id"],
                self._get_host_url(),
                data_points,  # type: ignore
            )
            log_query_result_items.append(item)

        return log_query_result_items

    def enqueue_export_collection(
        self,
        collection_uuid: str,
        plugin_server_name: str,
        options: list[PluginSchemaOption] = [],
    ) -> ExportCollectionJob | None:
        """
        Enqueue a job to export a Strada collection. In order to use this, the
        ExportCollections plugin must be implemented.

        Args:
            collection_uuid (str): The uuid of the collection to be exported.
            plugin_server_name (str): The name of the plugin server to run.
            options(list[PluginSchemaOption], optional): Any additional options you want
                to be passed into the plugin as an argument. This can be used to
                customize the execution of the plugin.

        Returns:
            ExportCollectionJob or None: A Strada ExportCollectionJob object.

        Example:
            export_collection_job = strada_api.enqueue_export_collection(collection_uuid="collection_uuid", plugin_server_name="plugin_server_name")
        """
        request = {
            "collection_uuid": collection_uuid,
            "plugin_server_name": plugin_server_name,
            "options": [option.to_request_object() for option in options],
        }
        # TODO(123249): Throw errors instead of logging and returning None.
        content = self.post_request(
            API_ENDPOINTS.ENQUEUE_EXPORT_COLLECTION, request, "Error enqueuing collection export"
        )
        if content is not None:
            return ExportCollectionJob(self, job_uuid=content.get("jobUuid"))  # client
        return None

    def get_export_collection_statuses(self, job_uuid: str) -> list[ExportCollectionJobStatus]:
        """Gets the status of exporting [collections](https://home.applied.co/manual/strada/latest/#/curations/exporting_collection/exporting_collection?id=exporting-collection).

        [#tags] Public

        Args:
            job_uuid (str): The UUID that describes the job running the export collection request.

        Returns:
            list[ExportCollectionJobStatus]: A list of statuses for the job.

        Example:
            result = strada_api.get_export_collection_statuses(
                job_uuid="test_job_uuid"
            )

        """
        request = {
            "job_uuid": job_uuid,
        }
        content = self.post_request(
            API_ENDPOINTS.GET_EXPORT_COLLECTION_STATUSES, request, "Error fetching status"
        )
        if content is None:
            _LOGGER.warning("No job statuses found with job uuid %s", job_uuid)
            return []
        statuses = []
        for status in content["statuses"]:
            option_type = JobStatus.UNSET
            for job_status_enum in JobStatus:
                if job_status_enum.value == status.get("status"):
                    option_type = job_status_enum

            statuses.append(
                ExportCollectionJobStatus(
                    state=status.get("state"),
                    percentage_progress=status.get("percentageProgress"),
                    status=option_type,
                    error_traceback=status.get("errorTraceback"),
                )
            )
        return statuses

    def query_logs(
        self,
        query_str: str,
        filter_to_last_n_ingested_logs: int | None = None,
        query_type: LogSearchQueryType | None = LogSearchQueryType.DEFAULT_TIME_WINDOW,
    ) -> LogQueryResult | None:
        """Queries recently ingested logs using the provided query string. This matches the
        functionality provided on the Strada Explore page.

        [#tags] Public

        Args:
            query_str (str): The query string to search for logs. This query string must match the format of
                Strada Explore page query strings.
            filter_to_last_n_ingested_logs (int | None, optional): Filter the search to the last N successfully ingested logs.
                Defaults to the log limit configured on the Strada Explore page.
            query_type (LogSearchQueryType | None, optional): The type of log search query to be executed.
                Defaults to LogSearchQueryType.DEFAULT_TIME_WINDOW.

        Returns:
            LogQueryResult: The results of the query.

        Raises:
            Exception: If the query type is not a valid LogSearchQueryType.
            Exception: If there was an internal error parsing the results from the query.

        Example:
            results = strada_api.query_logs(
                query_str='"Ego Longitudinal Velocity":>5 "Ego Longitudinal Acceleration":<2"',
                filter_to_last_n_ingested_logs=100,
            )
        """
        if not isinstance(query_type, LogSearchQueryType):
            raise Exception(
                "Invalid LogSearch Query Type, please choose from of the available types. For more information, check the Strada Python Client (ADP SDK) section on the ADP documentation manual."
            )
        start_time = time.time()

        request = {
            "filter_string": query_str,
            "most_recent_logs_limit": filter_to_last_n_ingested_logs,
            "hostname": self._remote_hostname,
            "query_type": query_type.value,
        }

        content = self.post_request(API_ENDPOINTS.LOG_SEARCH, request, "Error querying for logs")
        assert content is not None
        if not content.get("resultJson"):
            print(f"No results found for query: {query_str}.")
            return None

        try:
            results = json.loads(content["resultJson"])
        except ValueError as e:
            raise Exception("Error parsing JSON results from query") from e

        log_query_result_items = self._parse_log_query_results(results)

        _LOGGER.info(
            "Querying over logs took %s seconds and returned %s results.",
            time.time() - start_time,
            len(log_query_result_items),
        )
        return LogQueryResult(log_query_result_items, content["common"]["status"])

    def query_logs_by_proto(
        self,
        builder_query: log_search_query_pb2.BuilderQuery,
        filter_to_last_n_ingested_logs: int | None = None,
        query_type: LogSearchQueryType | None = LogSearchQueryType.DEFAULT_TIME_WINDOW,
    ) -> LogQueryResult | None:
        """Queries recently ingested logs using the provided `BuilderQuery` proto. This matches the
        functionality provided on the Data Explorer Explore page.

        [#tags] Public

        Args:
            builder_query (log_search_query_pb2.BuilderQuery): The BuilderQuery proto to search for logs.
            filter_to_last_n_ingested_logs (int | None, optional): Filter the search to the last N successfully ingested logs.
                Defaults to the log limit configured on the Data Explorer Explore page.
            query_type (LogSearchQueryType | None, optional): The type of log search query to be executed.
                Defaults to LogSearchQueryType.DEFAULT_TIME_WINDOW.

        Returns:
            LogQueryResult: The results of the query.

        Raises:
            Exception: If the query type is not a valid LogSearchQueryType.
            Exception: If there was an internal error parsing the results from the query.

        Example:
            builder_query = log_search_query_pb2.BuilderQuery(
                log_metadata_query=log_search_query_pb2.MetadataQueryGroup(
                    operator=log_search_query_pb2.MetadataQueryGroup.LogicOperator.AND,
                    conditions=[
                        log_search_query_pb2.MetadataQueryCondition(
                            log_path_condition=log_search_query_pb2.RegexCondition(
                                operator=log_search_query_pb2.RegexCondition.Operator.EQUAL,
                                metric=log_search_query_pb2.Metric(
                                    metric_info=log_search_query_pb2.MetricInfo(name="Log path"),
                                ),
                                value="my_log_path",
                            )
                        )
                    ],
                ),
                per_tick_query=log_search_query_pb2.QueryGroup(
                    operator=log_search_query_pb2.QueryGroup.LogicOperator.AND,
                    conditions=[
                        log_search_query_pb2.QueryCondition(
                            boolean_condition=log_search_query_pb2.BooleanCondition(
                                operator=log_search_query_pb2.BooleanCondition.Operator.EQUAL,
                                metric=log_search_query_pb2.Metric(
                                    metric_info=log_search_query_pb2.MetricInfo(name="Ego Engaged"),
                                ),
                                value=True,
                            )
                        ),
                        log_search_query_pb2.QueryCondition(
                            nl_search_condition=log_search_query_pb2.NLSearchCondition(
                                operator=log_search_query_pb2.NLSearchCondition.Operator.PHRASE_MATCH,
                                value="pedestrian crossing the street",
                            )
                        ),
                    ],
                ),
            )
            results = strada_api.query_logs_by_proto(builder_query=builder_query, filter_to_last_n_ingested_logs=100)
        """
        if not isinstance(query_type, LogSearchQueryType):
            raise ValueError(
                "Invalid LogSearchQueryType, please choose from one of the available types. For more information, check the Data Explorer Python Client (ADP SDK) section in the ADP manual."
            )

        start_time = time.time()

        request = {
            "builder_query": json_format.MessageToDict(
                builder_query, preserving_proto_field_name=True
            ),
            "most_recent_logs_limit": filter_to_last_n_ingested_logs,
            "hostname": self._remote_hostname,
            "query_type": query_type.value,
        }

        content = self.post_request(API_ENDPOINTS.LOG_SEARCH, request, "Error querying for logs")
        if content is None:
            raise ADPSDKError("Error while executing query")

        if not content.get("resultJson"):
            _LOGGER.info("No results found for query.")
            return None

        try:
            results = json.loads(content["resultJson"])
        except ValueError as e:
            raise ADPSDKError("Error parsing JSON results from query") from e

        log_query_result_items = self._parse_log_query_results(results)

        _LOGGER.info(
            "Querying over logs took %s seconds and returned %s results.",
            time.time() - start_time,
            len(log_query_result_items),
        )
        return LogQueryResult(log_query_result_items, content["common"]["status"])

    def add_events_to_collection(
        self, collection: Collection, events: typing.Sequence[LogInterval] = []
    ) -> Collection:
        """Add events to an existing [collection](https://home.applied.co/manual/strada/latest/#/curations/adding_to_collection/adding_to_collection?id=adding-to-collection).

        [#tags] Public

        Args:
            collection (Collection): The existing collection.
            events (LogInterval[], optional): List of events to add to the collection.

        Returns:
            Collection: The updated Strada collection object.

        Example:
            from adp.public.strada.models import object_models
            collection = object_models.Collection(
                client=StradaClient(),
                id=1,
                name="test_collection"
            )
            events=[
                object_models.LogInterval(
                    client=StradaClient(),
                    log_uuid="test_log_uuid",
                    instantaneous_timestamp_ms=10000,
                    start_timestamp_ms=10000,
                    end_timestamp_ms=50000,
                    uuid="test_event_uuid"
                )
            ]
            results = strada_api.add_events_to_collection(
                collection=collection,
                events=events
            )
        """
        if not events:
            return collection

        event_details = []
        for interval in events:
            event_details.append(
                {
                    "drive_uuid": interval.log_uuid,
                    "event_time_ms": interval.instantaneous_timestamp_ms,
                    "event_start_time_ms": interval.start_timestamp_ms,
                    "event_end_time_ms": interval.end_timestamp_ms,
                }
            )
        request = {
            "collection_name": collection.name,
            "event_details": event_details,
        }
        self.post_request(
            API_ENDPOINTS.ADD_INTERVALS_TO_COLLECTION, request, "Error creating collection."
        )
        # Reload events in the collection to update it.
        assert collection.id is not None
        return self.get_collection_by_id(collection.id)

    def create_collection(
        self, name: str, events: typing.Optional[list[typing.Type[LogInterval]]] = []
    ) -> Collection:
        """Create a new [collection](https://home.applied.co/manual/strada/latest/#/curations/adding_to_collection/adding_to_collection?id=adding-to-collection).

        [#tags] Public

        Args:
            name (str): The name for the collection.
            events (LogInterval[]): typing.Optional list of events to add to collection.

        Returns:
            Collection: A Strada collection object.

        Example:
            events=[
                object_models.LogInterval(
                    client=StradaClient(),
                    log_uuid="test_log_uuid",
                    instantaneous_timestamp_ms=10000,
                    start_timestamp_ms=10000,
                    end_timestamp_ms=50000,
                    uuid="test_event_uuid"
                )
            ]
            results = strada_api.create_collection(
                name='my-test-collection',
                events=events
            )
        """

        event_details = []
        if events:
            for interval in events:
                event_details.append(
                    {
                        "drive_uuid": interval.log_uuid,
                        "event_time_ms": interval.instantaneous_timestamp_ms,
                        "event_start_time_ms": interval.start_timestamp_ms,
                        "event_end_time_ms": interval.end_timestamp_ms,
                    }
                )
        request = {
            "collection_name": name,
            "event_details": event_details,
        }
        response = self.post_request(
            API_ENDPOINTS.ADD_INTERVALS_TO_COLLECTION, request, "Error creating collection."
        )
        assert response is not None
        collection_id = response.get("collectionId", None)
        collection_uuid = response.get("collectionUuid", None)
        if collection_id is None or collection_uuid is None:
            raise Exception("Error creating collection")
        assert collection_id is not None
        return self.get_collection_by_id(collection_id)

    def delete_collections(self, collection_ids: list[str]) -> None:
        """
        Deletes [collections](https://home.applied.co/manual/strada/latest/#/curations/adding_to_collection/adding_to_collection?id=adding-to-collection) by ID.

        [#tags] Public

        Args:
            collection_ids (List[str]): The IDs of the collections to delete.

        Example:
            strada_api.delete_collections(
                collection_ids=["1234"]
            )
        """
        # TODO(172745): The API here should be deleting by uuid or specifying id as an int and not a string.
        if not collection_ids:
            raise Exception("No collection IDs provided")
        request = {"collection_ids": collection_ids}
        self.post_request(API_ENDPOINTS.DELETE_COLLECTIONS, request, "Error deleting collection.")

    def get_collection_by_id(self, collection_id: int) -> Collection:
        """
        Get collection by collection id.

        Args:
            collection_id (int): The id of the collection to retrieve.

        Returns:
            Collection: A Strada collection object.

        Example:
            collection = strada_api.get_collection_by_id(collection_id=5)
        """
        request = {"id": collection_id}
        response = self.post_request(
            API_ENDPOINTS.GET_COLLECTION_DATA, request, "Error getting collection by id"
        )
        assert response is not None
        collection = response.get("eventCollection", {})
        events = response.get("events", [])
        return self._create_collection_from_collection_data_response(collection, events)

    def get_collection_by_name(self, name: str) -> Collection:
        """
        Get collection by collection name.

        Args:
            name (str): The name of the collection to retrieve.

        Returns:
            Collection: A Strada collection object.

        Example:
            collection = strada_api.get_collection_by_name(name="collection_name")
        """
        request = {"name": name}
        response = self.post_request(
            API_ENDPOINTS.GET_COLLECTION_DATA, request, "Error getting collection by name"
        )
        assert response is not None
        collection = response.get("eventCollection", {})
        events = response.get("events", [])
        return self._create_collection_from_collection_data_response(collection, events)

    def _create_collection_from_collection_data_response(
        self, collection: dict, events: list
    ) -> Collection:
        """
        Creates collection from the response of GET_COLLECTION_DATA.

        Args:
            collection (dict): The metadata of the collection to create.
            events (list): A list of events that are part of the collection.

        Returns:
            Collection: A Strada collection object.
        """
        event_results = []
        for event in events:
            timestamp = datetime.fromisoformat(event["logOffset"][:-1])
            start_timestamp = datetime.fromisoformat(
                event["datasetInterval"]["startTimeOffset"][:-1]
            )
            end_timestamp = datetime.fromisoformat(event["datasetInterval"]["endTimeOffset"][:-1])

            log_interval = LogInterval(
                self,
                event["driveRunUuid"],
                _get_milliseconds_since_epoch(timestamp),
                _get_milliseconds_since_epoch(start_timestamp),
                _get_milliseconds_since_epoch(end_timestamp),
                event["uuid"],
                self._get_host_url(),
            )
            event_results.append(log_interval)
        return Collection(
            self,
            collection.get("uuid", None),
            collection.get("id", None),
            collection.get("name", None),
            collection.get("numEvents", 0),
            event_results,
        )

    def list_collections(self) -> list[Collection]:
        """
        Lists all Collections in Strada.

        Returns:
            list[Collection]: A list of Strada collection objects.

        Example:
            collections = strada_api.list_collections()
        """
        response = self.post_request(
            API_ENDPOINTS.LIST_COLLECTIONS, {}, "Error getting list of collections in Strada"
        )
        assert response is not None
        collections = []
        for collection in response.get("eventCollections", []):
            collection_object = Collection(
                self,
                collection.get("uuid", None),
                collection.get("id", None),
                collection.get("name", None),
                collection.get("numEvents", 0),
            )
            collections.append(collection_object)
        return collections

    def get_supported_collection_export_options(self) -> SupportedPluginSchemaOptions:
        """
        Gets the supported collection plugin export schema options. This returns the options specified in your
        get_export_options plugin.

        Returns:
            SupportedPluginSchemaOptions: The schema options you can specify for the export collections plugin.
        """
        response = self.post_request(
            API_ENDPOINTS.GET_SUPPORTED_EXPORT_COLLECTION_PLUGIN_OPTIONS,
            {},
            "Error getting supported export collection plugin options",
        )
        assert response is not None
        supported_plugin_schema_options: list[PluginSchemaOption] = []
        for option in response.get("options", []):
            # Find the option value name
            option_type = None
            for option_key_value in PluginSchemaOptionType:
                if option_key_value.value not in option:
                    continue
                option_type = option_key_value
                break
            assert (
                option_type is not None
            ), f"None of {[val.value for val in PluginSchemaOptionType]} option types was not found on the plugin option response"

            multiselect_options = option.get("multiSelect", {}).get("multiselectOptions", [])
            option_value = option.get(option_type.value)
            # If the type is multiSelect, value should be the list in the multiSelect dictionary
            if option_type == PluginSchemaOptionType.MULTI_SELECT:
                option_value = multiselect_options

            plugin_schema_object = PluginSchemaOption(
                name=option.get("optionName", None),
                type=option_type,
                multiselect_options=multiselect_options,
                value=option_value,
            )
            supported_plugin_schema_options.append(plugin_schema_object)
        return SupportedPluginSchemaOptions(supported_plugin_schema_options)

    def get_dataset(self, name: str) -> Dataset:
        """Get an existing Strada dataset.

        Args:
            name (str): The name of the queried dataset.

        Returns:
            Dataset: A Strada dataset object.

        Example:
            results = strada_api.get_dataset(name="dataset_name")
        """
        items = self._get_dataset_contents(name)
        return Dataset(self, name, items)

    def create_dataset_items_from_events(
        self,
        events: list[typing.Type[LogInterval]],
    ) -> None:
        """Creates [dataset items](https://home.applied.co/manual/strada/latest/#/curations/adding_to_dataset/adding_to_dataset?id=adding-to-dataset) from a list of [events](https://home.applied.co/manual/strada/latest/#/overview/data_model/data_model?id=event).

        [#tags] Public

        Args:
            events (list[typing.Type[LogInterval]]): The list of events to create dataset items from.

        Example:
            from adp.public.strada.models import object_models
            events = [
                object_models.LogInterval(
                    client=StradaClient(),
                    log_uuid="test_log_uuid",
                    instantaneous_timestamp_ms=10000,
                    start_timestamp_ms=10000,
                    end_timestamp_ms=50000,
                    uuid="test_event_uuid"
                )
            ]
            strada_api.create_dataset_items_from_events(
                events=events
            )
        """
        # TODO(172745): Fix this endpoint.
        request = {"event_uuids": [event.uuid for event in events]}
        self.post_request(
            API_ENDPOINTS.CREATE_DATASET_ITEMS, request, "Error creating dataset items"
        )

    def _get_dataset_contents(self, name: str) -> list[DatasetItem]:
        """Gets contents from dataset by name.

        Returns:
            list[DatasetItem]: A list of Strada dataset items.
        """
        request = {"name": name}

        content = self.post_request(
            API_ENDPOINTS.GET_DATASET_METADATA, request, "Error getting Strada dataset."
        )
        assert content is not None
        items = []
        for item in content.get("items", []):
            timestamp = datetime.fromisoformat(item["logOffset"][:-1])
            dataset_item = DatasetItem(
                self,
                item["driveRunUuid"],
                _get_milliseconds_since_epoch(timestamp),
                item["uuid"],
            )
            items.append(dataset_item)

        return items

    def _check_uuid_and_return_url(self, content: typing.Any, job_name: str) -> str:
        """Validates uuid exists in given response content and generates the URL by uuid and job_name.

        Returns:
            str: URL of job. Empty string if uuid is missing in the response content.
        """
        if not content.get("uuid"):
            print(
                "Server did not respond with a valid ingestion response. Unable to find tracking UUID."
            )
            return ""

        uuid = content.get("uuid")
        url = "{}/strada/library/drives/{}".format(self._get_host_url(), uuid)

        print(f"Track progress of your {job_name} job here: {url}")
        return url

    def _post_add_data_to_log_request(
        self, log: str, ingestion_channels: list[dict], job_name: str = "incremental ingestion"
    ) -> str:
        """Submit a POST request to add data to a log via an incremental ingestion.

        Args:
            log (str): The log to add data to.
            ingestion_channels (list[dict]): The ingestion channels to ingest data again.
            job_name (str, optional): The name of the incremental ingestion job. Defaults to "incremental ingestion".

        Returns:
            str: The URL to check the incremental ingestion status.
        """
        request = {"log_path": log, "channels": ingestion_channels}

        content = self.post_request(
            API_ENDPOINTS.ADD_DATA_TO_STRADA_LOG,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.ADD_DATA_TO_STRADA_LOG, ""),
        )
        assert content is not None
        if not content.get("common", {}).get("status") == "SUCCESS":
            error_msg = content.get("common", {}).get("exception", {}).get("exception_message")
            print(f"Unexpected error with adding data to log: {error_msg}")
            return ""

        return self._check_uuid_and_return_url(content, job_name)

    def add_data_to_log(
        self, log: str, ingest_channel_requests: list[AbstractIngestChannelRequest]
    ) -> str:
        """Enqueues an incremental ingestion run for the given log path
        and specified channel names. It is required for this log to have been successfully
        ingested at least once into Strada.

        Args:
            log (str): The name of the log to incrementally ingest.
            channel_names (list[AbstractIngestChannelRequest]): A list of channels to incrementally ingest.

        Returns:
            str: URL to track progress of the incremental ingestion.

        Example:
            from adp.public.strada.models import ingestion_models
            ingestion_channel = ingestion_models.IngestChannelRequestFactory.from_custom(
                name = 'camera_1',
                type = IngestChannelType.CAMERA,
                extra_data = {'source_path': '/path/to/file'}
            )
            url = strada_api.add_data_to_log('my_log_path', [ingestion_channel])
        """

        ingestion_channels = []
        external_proto = plugin_pb2.FinalizePostprocessResultsResponse()
        for channel in ingest_channel_requests:
            if channel.conversion_method == ConversionMethod.CUSTOM:
                channel_dict = {
                    "name": channel.channel_name,
                    "type": channel.channel_type.value,
                    "extra_data": channel.extra_data,
                }
                ingestion_channels.append(channel_dict)
            elif channel.conversion_method in [
                ConversionMethod.BOOLEAN_STAT,
                ConversionMethod.NUMBER_STAT,
            ]:
                external_proto.MergeFrom(channel.external_result_proto)

        # TODO(michelletan2): Submit external proto for ingestion.
        return self._post_add_data_to_log_request(log, ingestion_channels, "incremental ingestion")

    def replace_data_in_log(self, log: str, channels_to_replace: list[str]) -> str:
        """Enqueues an incremental ingestion run for the given log path
        and specified channel names. It is required for this log to have been successfully
        ingested at least once into Strada with these channels.

        [#tags] Public

        Args:
            log (str): The name of the log to incrementally ingest.
            channel_names (list[str]): A list of channel names to replace.

        Returns:
            string: A URL to track the progress of channel replacement.

        Example:
            strada_api.replace_data_in_log('my_log_path', ['camera_name_1', 'camera_name_2'])
        """

        ingestion_channels = []
        for channel in channels_to_replace:
            channel_dict = {
                "name": channel,
            }
            ingestion_channels.append(channel_dict)

        return self._post_add_data_to_log_request(log, ingestion_channels, "channel replacement")

    def _post_convert_strada_drive(
        self, request: dict, job_name: str = "log conversion"
    ) -> tuple[str, str]:
        """Submit a POST request to ingest a Strada log. This is a synchronous request that will
        only return after request processing begins.

        Args:
            request (dict): The convert Strada drive request that matches the format of public_triage_service_pb2.ConvertDriveRequest.
            job_name (str, optional): The job name. Defaults to "log conversion".

        Returns:
            str: A string url to track the progress of the job.
            str: A string representing the uuid of the created drive on Data Explorer.
        """
        content = self.post_request(
            API_ENDPOINTS.CONVERT_STRADA_DRIVE,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.CONVERT_STRADA_DRIVE, ""),
        )
        assert content is not None
        url: str = self._check_uuid_and_return_url(content, job_name)
        return url, content.get("uuid")

    def _post_enqueue_log_ingestion(self, request: dict) -> None:
        """Submit a POST request to ingest a Strada log.This is an asynchronous request that will return
        immediately after the request is enqueued. Use this endpoint if you need to bulk ingest logs.

        Args:
            request (dict): The enqueue log ingestion request that matches the format of public_triage_service_pb2.ConvertDriveAsyncRequest.
        """
        content = self.post_request(
            API_ENDPOINTS.ENQUEUE_LOG_INGESTION,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.ENQUEUE_LOG_INGESTION, ""),
        )
        assert content is not None
        if not content.get("common", {}).get("status") == "SUCCESS":
            error_msg = content.get("common", {}).get("exception", {}).get("exception_message")
            print(f"Unexpected error with enqueueing log ingestion: {error_msg}")
            return

        print("Your ingestion was enqueued successfully.")

    def _populate_request_with_metadata_and_parameters(
        self,
        log_ingestion_metadata: LogIngestionMetadata,
        ingestion_parameters: IngestionParameters,
    ) -> dict:
        """Populate the request with required log ingestion metadata and parameters for ingestion.

        Args:
            log_ingestion_metadata (LogIngestionMetadata): The log metadata for the log.
            ingestion_parameters (IngestionParameters): The ingestion parameters for the request.

        Returns:
            dict: The convert drive request.
        """
        custom_fields = [
            custom_field.to_json_dict() for custom_field in log_ingestion_metadata.custom_fields
        ]
        events = [event.to_json_dict() for event in log_ingestion_metadata.events]

        request = {
            "drive_duration_secs": ingestion_parameters.log_duration_secs,
            "test_cycle_id": log_ingestion_metadata.test_cycle_id,
            "max_auto_retries": ingestion_parameters.max_auto_retries,
            "drive_name": log_ingestion_metadata.log_name,
            "map_key": log_ingestion_metadata.map_key,
            "requirement_uuid": log_ingestion_metadata.requirement_uuid,
            "sim_flags": ingestion_parameters.sim_flags,
            "trailing_yaml": ingestion_parameters.trailing_yaml,
            "tenant_name": ingestion_parameters.tenant_name,
            "custom_fields": custom_fields,
            "include_file_paths": ingestion_parameters.include_file_paths,
            "is_partial": ingestion_parameters.is_partial,
            "events": events,
        }

        if ingestion_parameters.log_permissions:
            request["log_permissions"] = ingestion_parameters.log_permissions.to_json_dict()

        log_sources = []
        for log in log_ingestion_metadata.logs:
            log_sources.append(
                {
                    "name": log.name,
                    "path": log.path,
                    "start_offset": {
                        "seconds": int(log.start_offset_seconds),
                        "nanoseconds": (log.start_offset_seconds - int(log.start_offset_seconds))
                        * 1e9,
                    },
                }
            )
        request["logs"] = log_sources

        return request

    def ingest_strada_log_with_config_path(
        self, request: IngestLogsWithPathRequest
    ) -> tuple[str, str]:
        """Ingests data to a log with a drive config.

        Args:
            request (IngestLogsWithPathRequest): The request for the log ingestion.

        Example:
            from adp.public.strada.models import ingestion_models
            request = ingestion_models.IngestLogsWithPathRequest(
                ingestion_path_config = ingestion_models.IngestionPathConfig(drive_config_path="scenario://workspace/drive-converters/config.drv.yaml"),
                log_ingestion_metadata = ingestion_models.LogIngestionMetadata(logs=[ingestion_models.LogSource(name="default", path="log_path")], map_key="sunnyvale"),
                ingestion_parameters = ingestion_models.IngestionParameters(log_duration_secs=10, sim_flags="--customer_server_run_cmd='python /drive_converter/drive_converter.py' --container_name example_container"))
            )
            strada_api.ingest_strada_log_with_config_path(request)
        """
        convert_drive_request = self._populate_request_with_metadata_and_parameters(
            request.log_ingestion_metadata, request.ingestion_parameters
        )
        convert_drive_request["drive_config_path"] = request.ingestion_path_config.drive_config_path
        convert_drive_request[
            "run_environment_name"
        ] = request.ingestion_path_config.run_environment_name
        convert_drive_request["workspace"] = request.ingestion_path_config.workspace
        return self._post_convert_strada_drive(convert_drive_request)

    def ingest_strada_log_with_ingestion_mode(self, request: IngestLogsWithModeRequest) -> None:
        """Enqueues an ingestion to a log with configured images. See [here](https://home.applied.co/manual/strada/latest/#/configuration/log_ingestion) to learn more.

        Args:
            request (IngestLogsWithModeRequest): The request for the log ingestion.
        """
        convert_drive_request = self._populate_request_with_metadata_and_parameters(
            request.log_ingestion_metadata, request.ingestion_parameters
        )
        convert_drive_request["log_ingestion_config"] = {
            "ingestion_image": request.ingestion_image_config.ingestion_image,
            "ingestion_mode": request.ingestion_image_config.ingestion_mode,
            "configured": request.ingestion_image_config.configured,
        }
        self._post_enqueue_log_ingestion(convert_drive_request)

    def revoke_permissions_on_log(self, log_path: str, users: list[str]) -> None:
        self.delete_request_with_query_parameters(
            endpoint_enum=API_ENDPOINTS.UPDATE_LOG_PERMISSIONS,
            params=[log_path],
            error_msg=f"Error revoking permissions on log {log_path}",
            request={"users": users},
        )

    def revoke_default_permission_on_log(self, log_path: str) -> None:
        self.delete_request_with_query_parameters(
            endpoint_enum=API_ENDPOINTS.UPDATE_LOG_PERMISSIONS,
            params=[log_path],
            error_msg=f"Error revoking default permission on log {log_path}",
            request={"revoke_default_permission": True},
        )

    def grant_permissions_on_log(self, log_path: str, user_roles: list[LogUserRole]) -> None:
        self.post_request_with_path_parameters(
            endpoint_enum=API_ENDPOINTS.UPDATE_LOG_PERMISSIONS,
            params=[log_path],
            error_msg=f"Error granting permissions on log {log_path}",
            request={
                "log_permissions": {
                    "user_roles": [user_role.to_json_dict() for user_role in user_roles]
                }
            },
        )

    def grant_default_permission_on_log(self, log_path: str, permission: DefaultLogAccess) -> None:
        self.post_request_with_path_parameters(
            endpoint_enum=API_ENDPOINTS.UPDATE_LOG_PERMISSIONS,
            params=[log_path],
            error_msg=f"Error granting permissions on log {log_path}",
            request={"log_permissions": {"default_access_level": permission.value}},
        )

    def revoke_permissions_on_collection(
        self, collection_uuid: str, users: list[str], revoke_default_permission: bool = False
    ) -> None:
        self.delete_request_with_query_parameters(
            endpoint_enum=API_ENDPOINTS.UPDATE_COLLECTION_PERMISSIONS,
            params=[collection_uuid],
            error_msg=f"Error revoking permissions on collection with uuid {collection_uuid}",
            request={
                "users": users,
                "revoke_default_permission": revoke_default_permission,
            },
        )

    def grant_permissions_on_collection(
        self,
        collection_uuid: str,
        user_roles: list[CollectionUserRole],
        default_permission: DefaultCollectionAccess = DefaultCollectionAccess.NONE,
    ) -> None:
        self.put_request_with_path_parameters(
            endpoint_enum=API_ENDPOINTS.UPDATE_COLLECTION_PERMISSIONS,
            params=[collection_uuid],
            error_msg=f"Error granting permissions on collection with uuid {collection_uuid}",
            request={
                "collection_permissions": {
                    "user_roles": [user_role.to_json_dict() for user_role in user_roles],
                    "default_access_level": default_permission.value,
                }
            },
        )

    def get_queryable_logs(self) -> list[Log]:
        """Gets a list of logs that are queryable on the Strada Explore page.
        Those log objects include the available metadata for that log.

        [#tags] Public

        Raises:
            Exception: If there are no queryable logs fetched from the backend.
            ADPBugError: If there are internal errors while requesting the queryable logs.

        Returns:
            list[Log]: The list of queryable logs.
        """
        request: dict = {}
        content = self.post_request(
            API_ENDPOINTS.GET_QUERYABLE_LOGS,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.GET_QUERYABLE_LOGS, ""),
        )
        assert content is not None
        try:
            logs = content["drives"]
        except (ValueError, KeyError) as e:
            raise ADPBugError(
                f"Unexpected bug occurred when getting queryable logs. Contact Applied Intuition for support. {e}"
            )
        if not logs:
            raise Exception("No available queryable logs.")
        try:
            list_logs: list[Log] = [
                Log(
                    uuid=log["uuid"],
                    simulation_run_id=log["simulationRunId"],
                    created_at=datetime_from_datetime_string(str(log["createdAt"])),
                    start_time=datetime_from_datetime_string(str(log["startTime"]))
                    if "startTime" in log and log["startTime"] is not None
                    else None,
                    vehicle_name=log.get("vehicleName", None),
                    tags=log.get("tags", []),
                )
                for log in logs
            ]
            return list_logs
        except Exception as e:
            raise ADPBugError(
                f"Unexpected bug occurred when getting queryable logs. Contact Applied Intuition for support. {e}"
            )

    def get_tick_level_data_for_drive(
        self,
        drive_uuid: str,
    ) -> pd.DataFrame:
        """
        Obtain a Pandas dataframe containing tick level data related to the specified drive UUID from Strada's Explore page.
        The dataframe will have a 'sim_time' column to record the simulation time for each data point, and each additional
        column will correspond to a metric name available on Strada's Explore page, representing computed values for the
        given drive. The combination of 'sim_time' and a metric column forms a time series that describes the evolution of
        that specific metric over time.

        Args:
            drive_uuid (str): uuid describing the drive run for an ingested log.
        """
        request: dict = {"drive_uuid": drive_uuid}
        content = self.post_request(
            API_ENDPOINTS.GET_TICK_LEVEL_DATA_FOR_DRIVE,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.GET_TICK_LEVEL_DATA_FOR_DRIVE, ""),
        )
        assert content is not None
        download_url = content["downloadUrl"]
        column_mapping = content["columnNameMapping"]

        try:
            df = pd.read_parquet(path=download_url, engine="pyarrow")
        except Exception as e:
            raise Exception(f"Error downloading tick level data with Exception: {e}")

        if not column_mapping:
            _LOGGER.warning(
                "No column mapping found for drive uuid %s available. Returning column names that might not match the listed metric names in Strada's Explore page",
                drive_uuid,
            )
            return df

        df.rename(columns=column_mapping, inplace=True)
        return df

    def edit_events_by_uuid(
        self, uuids: list[str], editing_config: TriageEventEditingConfig
    ) -> None:
        """Applies the specified edits to the [triage events](https://home.applied.co/manual/strada/latest/#/overview/data_model/data_model?id=event) identified by the given UUIDs.

        [#tags] Public

        Args:
            uuids (list[str]): The list of event UUIDs that should be edited.
            editing_config (TriageEventEditingConfig): The specification of edits that should be applied.

        Example:
            from adp.public.strada.models import triage_models

            editing_config = triage_models.TriageEventEditingConfig(
                status_to_add = "my-new-status"
            )
            strada_api.edit_events_by_uuid(
                uuids=['my-uuid-1', 'my-uuid-2'],
                editing_config=editing_config,
            )
        """
        validate_message = editing_config.validate()
        # If there is message, then the editing config is invalid.
        # We print the message and return early.
        if validate_message:
            raise ValueError(validate_message)

        request = editing_config.get_constructed_edit_request()
        request["event_identifier"] = {"event_uuids": {"uuids": uuids}}

        content = self.post_request(
            API_ENDPOINTS.EDIT_TRIAGE_EVENTS,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.EDIT_TRIAGE_EVENTS, ""),
        )
        assert content is not None
        if not content.get("common", {}).get("status") == "SUCCESS":
            error_msg = content.get("common", {}).get("exception", {}).get("exception_message")
            raise RuntimeError(f"Unexpected error with editing triage events: {error_msg}")

        print("Your events were successfully edited.")

    def _post_query_request(
        self, query_str: str, user_facing_error_message: str | None
    ) -> typing.Any:
        """Submit a POST GraphQL request.

        Args:
            query_str (str): The GraphQL query.
            user_facing_error_message (str | None): The custom error message to show.

        Raises:
            RuntimeError: If there was an internal error in the content response returned by the server.

        Returns:
            typing.Any: The queried results.
        """
        request = {"query_str": query_str}
        content = self.post_request(
            API_ENDPOINTS.QUERY,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.QUERY, ""),
        )
        if content is None:
            raise RuntimeError("Unexpected error with posting query request.")

        error_message = content.get("error_message", [])
        if len(error_message) > 0:
            raise RuntimeError(user_facing_error_message or error_message[0])

        return content

    def get_latest_drive_for_log(self, log_path: str) -> Log:
        """
        Gets the latest ingestion for the given log path.

        [#tags] Public

        Args:
            log_path (str): The log path to identify the given log.

        Throws:
            RuntimeError: If no logs are found for the given log path.

        Returns:
            Log: An object that will contain the uuid and simulation run id
                to uniquely identify the latest ingestion of this log in ADP.
        """
        query = QUERY_STRINGS["latest_drive_from_log_path"].format(log_path=log_path)
        content = self._post_query_request(
            query_str=query,
            user_facing_error_message="Unexpected error with querying for the latest drive UUID for log path.",
        )

        log_conversions = content.get("logConversions", [])
        if len(log_conversions) == 0:
            raise RuntimeError(f"Unable to find any logs with given log path {log_path}")

        log_conversion = log_conversions[0]
        latest_drive = log_conversion.get("latestDrive")
        if not latest_drive:
            raise RuntimeError(f"Unable to find the latest drive for given log path {log_path}")

        created_at_datetime = datetime_from_datetime_string(latest_drive["createdAt"])
        start_time_datetime = latest_drive["startTime"] and datetime_from_datetime_string(
            latest_drive["startTime"]
        )

        return Log(
            uuid=latest_drive["uuid"],
            simulation_run_id=latest_drive["simulationRunId"],
            created_at=created_at_datetime,
            start_time=start_time_datetime,
        )

    def query_for_event_uuids_using_search_term(
        self, search_term: str, max_results: int = MAX_EVENT_QUERY_RESULTS
    ) -> list[str]:
        """
        Queries for event UUIDs matching the provided search term.

        [#tags] Public

        Args:
            search_term (str): The search term follows the Strada Events page query syntax.
                You can use any search term from the Events page search bar in Strada.

        Returns:
            list[str]: A list of UUIDs used to uniquely identify events
                that match the given search term.

        Raises:
            ValueError: If the requested maximum number of results is invalid.
            RuntimeError: If there was an internal error while querying for the event UUIDs.

        Example:
            event_uuids = strada_api.query_for_event_uuids_using_search_term(
                search_term="reason:'DISENGAGEMENT' AND eventStatus:'PENDING' AND assigneeEmail:'abc@applied.co'",
                max_results=100,
            )
        """

        if max_results > MAX_EVENT_QUERY_RESULTS:
            raise ValueError(
                f"The maximum number of results is {MAX_EVENT_QUERY_RESULTS}. Please specify a lower number of maximum results to return.",
            )
        elif max_results <= 0:
            raise ValueError("Maximum results must be a postive integer.")

        query = QUERY_STRINGS["event_uuids_from_search_term"].format(
            max_results=max_results, search_term=search_term
        )
        content = self._post_query_request(
            query_str=query,
            user_facing_error_message="Unexpected error with querying for the event UUIDs.",
        )

        triageEventsConnection = content.get("triageEventsConnection")
        if not triageEventsConnection:
            raise RuntimeError(f"Unable to find results for given search query: {search_term}")
        edges = triageEventsConnection.get("edges", [])
        if len(edges) == 0:
            print("There are no results for the given search query.")
            return []

        event_uuids = []
        for edge in edges:
            node = edge.get("node")
            if not node:
                raise RuntimeError("Invalid event format returned from server %s", str(edge))
            uuid = node.get("uuid")
            if not uuid:
                raise RuntimeError("Event result does not have corresponding uuid %s", str(node))
            event_uuids.append(uuid)

        return event_uuids

    def add_events_to_log(self, drive_uuid: str, events: list[TriageEvent]) -> None:
        """Adds [events](https://home.applied.co/manual/strada/latest/#/overview/data_model/data_model?id=event) to a log.

        Args:
            drive_uuid (str): The UUID of the log to add events to.
            events (list[triage_models.TriageEvent]): Events to be added.

        Raises:
            RuntimeError: If the request to the server returned with no contents.
            RuntimeError: If the server encountered an issue adding events to the log.

        Example:
            from adp.public.strada.models import triage_models
            events = [
                triage_models.TriageEvent(
                    uuid="test_event_uuid",
                    relative_offset=triage_models.RelativeOffset(
                        time_secs=1.0,
                        start_time_secs=1.0,
                        end_time_secs=5.0,
                    )
                )
            ]
            results = strada_api.add_events_to_log(
                drive_uuid = "test_uuid",
                events = events
            )
        """
        request = {
            "drive": {"uuid": drive_uuid},
            "events": [event.to_json_dict() for event in events],
        }
        content = self.post_request(
            API_ENDPOINTS.ADD_TRIAGE_DRIVE_EVENTS,
            request,
            ERROR_MESSAGES.get(API_ENDPOINTS.ADD_TRIAGE_DRIVE_EVENTS, ""),
        )
        if content is None:
            raise RuntimeError("Unable to successfully post request to server.")

        if not content.get("common", {}).get("status") == "SUCCESS":
            error_msg = content.get("common", {}).get("exception", {}).get("exception_message")
            raise RuntimeError(f"Unexpected error with adding triage events to log: {error_msg}")

    def edit_log_metadata_by_log_path(
        self, log_paths: list[str], editing_config: LogEditingConfig
    ) -> None:
        """
        Edit the metadata on the specified logs based on the given editing config. This will
        not edit the underlying data within the logs.

        Args:
            log_paths (list[str]): A list of valid log paths that you want to edit.
            editing_config (LogEditingConfig): The specification of edits that should be applied.

        Example:
            from adp.public.strada.models import object_models
            from adp.public.strada.models import custom_field_models

            custom_field = custom_field_models.CustomFieldFactory.create_custom_field_from_name_value_pair(
                name=custom_field_name,
                is_user_editable=True,
                source_type=custom_field_models.SourceType.LOG,
                value=custom_field_value,
            )
            editing_config = object_models.LogEditingConfig(
                custom_field = custom_field
            )
            strada_client.edit_logs_by_log_path(log_paths = ['my-log-path-1', 'my-log-path-2'], editing_config = editing_config)

        """

        simulation_run_ids = []
        for log_path in log_paths:
            # If a log path is invalid, then this will raise a RuntimeError
            # which will be surfaced to the end user.
            latest_drive = self.get_latest_drive_for_log(log_path=log_path)
            simulation_run_ids.append(latest_drive.simulation_run_id)

        # Note - this function can be expanded in the future to support other type of
        # log edits.
        if editing_config.custom_field:
            request = {
                "simulation_run_identifier": {
                    "simulation_run_ids": {"ids": simulation_run_ids},
                },
                "custom_field": editing_config.custom_field.to_json_dict(),
            }
            content = self.post_request(
                API_ENDPOINTS.EDIT_SIMULATION_RUN_CUSTOM_FIELD,
                request,
                ERROR_MESSAGES.get(API_ENDPOINTS.EDIT_SIMULATION_RUN_CUSTOM_FIELD, ""),
            )
            if content is None:
                raise RuntimeError("Unable to successfully post request to server.")

            print("Successfully applied custom field edits to your log(s).")

        print("Successfully applied all edits to your log(s).")

    def enqueue_parallelized_export_collections(
        self,
        collection_uuid: str,
        plugin_executor: PluginExecutor,
        parallelization_mode: EXPORT_COLLECTIONS_PARALLELIZATION_MODE = EXPORT_COLLECTIONS_PARALLELIZATION_MODE.BY_EVENT,
        options: list[PluginSchemaOption] = [],
        allowed_channels: list[str] = [],
        max_retries: int = 1,
    ) -> ParallelizedExportCollectionJob | None:
        """
        Enqueues an export job on a collection that exports the events in parallel.
        In order to use this, the [ExportCollection plugin](/docs/data_explorer/integrating_with_data_explorer/export_collection_plugin/)
        must be implemented.
        The parallelization of the exports is controlled by the [parallelization_mode](/docs/data_explorer/export/export_parameters/#parallelization-modes) parameter.

        [#tags] Public

        Args:
            collection_uuid (str): The uuid of the collection to be exported.
            plugin_executor (PluginExecutor): The plugin executor. Use PluginServerName("plugin_server_name") or
                PluginQueueInfo("plugin_queue_name", "sidecar_name") to specify the executor type.
            parallelization_mode (EXPORT_COLLECTIONS_PARALLELIZATION_MODE): The
            options(list[PluginSchemaOption], optional): Any additional options you want
                to be passed into the plugin as an argument. This can be used to
                customize the execution of the plugin.
            allowed_channels (list[str], optional): The list of channel names that should be exported.
                This parameter is passed in the ExportCollectionRequest message to the plugin.
            max_retries (int, optional): The maximum number of retries for the export job. Defaults to 1.

        Returns:
            ParallelizedExportCollectionJob: A Strada ParallelizedExportCollectionJob object.

        Raises:
            ADPSDKError: If export job cannot be enqueued, or if there are no events to export.

        Example:
            parallelized_export_collection_job = strada_api.enqueue_parallelized_export_collections(collection_uuid="collection_uuid", plugin_executor=PluginQueueInfo("plugin_queue_name", "sidecar_name"))
        """

        req_parallelization_mode = EXPORT_COLLECTIONS_PARALLELIZATION_MODE.BY_EVENT
        for parallelization_mode_enum in EXPORT_COLLECTIONS_PARALLELIZATION_MODE:
            if parallelization_mode_enum.value == parallelization_mode:
                req_parallelization_mode = parallelization_mode_enum
        request = {
            "collection_uuids": [collection_uuid],
            "plugin_parameters": {
                **plugin_executor.to_proto(),  # Unpack the dictionary directly into the plugin_parameters
                "options": [option.to_request_object() for option in options],
            },
            "parallelization_mode": req_parallelization_mode.value,
            "allowed_channels": allowed_channels,
            "max_retries": max_retries,
        }

        content = self.post_request(
            API_ENDPOINTS.PARALLELIZED_EXPORT_COLLECTIONS,
            request,
            "Error enqueuing collection export",
        )

        if content is not None and content.get("exports") is not None:
            exports = content.get("exports")
            details = exports[0].get("details")
            subjob_uuids = []
            for jobs_with_status in details.get("exportCollectionSubjobs"):
                subjob_uuids.extend(jobs_with_status.get("uuid"))
            return ParallelizedExportCollectionJob(
                self,
                job_uuid=exports[0].get("uuid"),
                collection_uuid=details.get("collectionUuid"),
                created_at=details.get("createdAt"),
                subjob_uuids=subjob_uuids,
            )

        if content is not None and content.get("errorMsg") is not None:
            raise ADPSDKError(content.get("error_message"))
        raise ADPSDKError("Export job cannot be enqueued. Contact Applied Intuition for support.")

    def get_parallelized_export_log_collections_by_collection_uuid(
        self, collection_uuid: str
    ) -> list[ParallelizedExportCollectionJob]:
        """Gets the statuses of all exports of a given collection

        [#tags] Public

        Args:
            collection_uuid (str): The UUID that describes the collection that is exported.

        Returns:
            list[ParallelizedExportCollectionJob]: A list of all exports jobs of a collection

        Example:
            result = strada_api.get_parallelized_export_log_collections_by_collection_uuid(
                collection_uuid="test_collection_uuid"
            )

        """
        content = self.post_request_with_path_parameters(
            API_ENDPOINTS.PARALLELIZED_EXPORT_COLLECTIONS_BY_COLLECTION_UUID,
            [collection_uuid],
            None,
            "Error getting exports by collection uuid",
        )
        if content is None or content.get("exports") is None:
            _LOGGER.warning("No job statuses found with collection uuid %s", collection_uuid)
            return []

        exports = content.get("exports")
        jobs = []

        for export in exports:
            details = export.get("details")
            subjob_uuids = []
            for jobs_with_status in details.get("exportCollectionSubjobs"):
                subjob_uuids.extend(jobs_with_status.get("uuid"))
            jobs.append(
                ParallelizedExportCollectionJob(
                    self,
                    job_uuid=export.get("uuid"),
                    collection_uuid=details.get("collectionUuid"),
                    created_at=details.get("createdAt"),
                    subjob_uuids=subjob_uuids,
                )
            )

        return jobs

    def get_parallelized_export_log_collections_by_export_uuid(
        self, job_uuid: str
    ) -> list[ParallelizedExportCollectionSubjob]:
        """Gets the status of exporting collections

        Args:
            job_uuid (str): The UUID that describes the job running the export collection request.

        Returns:
            list[ParallelizedExportCollectionSubjob]: A list of subjobs for the export

        Example:
            result = strada_api.get_parallelized_export_log_collections_by_export_uuid(
                job_uuid="test_job_uuid"
            )

        """
        content = self.post_request_with_path_parameters(
            API_ENDPOINTS.PARALLELIZED_EXPORT_COLLECTIONS_BY_EXPORT_UUID,
            [job_uuid],
            None,
            "Error getting exports by export uuid",
        )

        if content is None or content.get("exports") is None:
            _LOGGER.warning("No job statuses found with job uuid %s", job_uuid)
            return []

        exports = content.get("exports")
        details = exports[0].get("details")
        subjobs = []

        for jobs_with_status in details.get("exportCollectionSubjobs"):
            status_type = ParallelizedExportCollectionJobStatus.UNSPECIFIED
            for job_status_enum in ParallelizedExportCollectionJobStatus:
                if job_status_enum.value == jobs_with_status.get("status"):
                    status_type = job_status_enum

            for subjob in jobs_with_status.get("uuid"):
                subjobs.append(
                    ParallelizedExportCollectionSubjob(
                        client=self, subjob_uuid=subjob, status=status_type
                    )
                )

        return subjobs

    def get_parallelized_export_log_collections_subjob_status(
        self, subjob_uuid: str
    ) -> ParallelizedExportCollectionSubjobExecution:
        """Gets the status of a subjob exporting a batch of events in a collection

        Args:
            job_uuid (str): The UUID that describes the subjob running the export of a particular batch of events in a collection

        Returns:
            ParallelizedExportCollectionSubjobExecution: execution details of the subjob

        Raises:
            RuntimeError: If the status of the subjob could not be found

        Example:
            result = strada_api.get_parallelized_export_log_collections_subjob_status(
                subjob_uuid="test_subjob_uuid"
            )
        """
        content = self.post_request_with_path_parameters(
            API_ENDPOINTS.PARALLELIZED_EXPORT_COLLECTIONS_SUBJOB_STATUS,
            [subjob_uuid],
            None,
            "Error getting execution status of subjob",
        )

        if content is None or content.get("subjobs") is None or len(content.get("subjobs")) == 0:
            _LOGGER.warning("No job statuses found with subjob uuid %s", subjob_uuid)
            raise RuntimeError("No job statuses found with subjob uuid %s", subjob_uuid)

        subjobs = content.get("subjobs")
        subjob = subjobs[0]
        execution = subjob.get("latestExecution")

        status_type = ParallelizedExportCollectionJobStatus.UNSPECIFIED
        for job_status_enum in ParallelizedExportCollectionJobStatus:
            if job_status_enum.value == execution.get("status"):
                status_type = job_status_enum

        subjob_execution = ParallelizedExportCollectionSubjobExecution(
            self,
            subjob_uuid,
            execution.get("percentageProgress", 0),
            execution.get("state", ""),
            execution.get("errorTraceback", ""),
            status_type,
        )

        return subjob_execution

    def rerun_export_log_collections_subjobs(
        self,
        subjob_uuids: list[str],
        plugin_executor: PluginExecutor,
        options: list[PluginSchemaOption] = [],
    ) -> list[ParallelizedExportCollectionSubjobExecution]:
        """
        Rerun a list of export subjobs with a different set of [export parameters](/docs/data_explorer/export/export_parameters/)

        [#tags] Public

        Args:
            subjob_uuid (list[str]): The UUIDs of the subjobs that need to be rerun
            plugin_executor (PluginExecutor): The plugin executor. Use PluginServerName("plugin_server_name") or
                PluginQueueInfo("plugin_queue_name", "sidecar_name") to specify the executor type.
            options(list[PluginSchemaOption], optional): Any additional options you want
                to be passed into the plugin as an argument. This can be used to
                customize the execution of the plugin.

        Returns:
            list[ParallelizedExportCollectionSubjobExecution]: execution details of the subjob

        Raises:
            RuntimeError: If execution status of the reran subjob could not be retrieved
            ADPSDKError: If an unexcepted internal error occurred

        Example:
            result = strada_api.rerun_export_subjobs(
                subjob_uuid=["subjob_uuid1", "subjob_uuid2"],
                plugin_executor=PluginQueueInfo("plugin_queue_name", "sidecar_name")
            )
        """
        request = {
            "subjob_uuids": subjob_uuids,
            "plugin_parameters": {
                **plugin_executor.to_proto(),  # Unpack the dictionary directly into the plugin_parameters
                "options": [option.to_request_object() for option in options],
            },
        }

        content = self.post_request(
            API_ENDPOINTS.PARALLELIZED_EXPORT_COLLECTIONS_RERUN_SUBJOBS,
            request,
            "Error rerunning export subjobs",
        )

        if content is not None and content.get("subjobs") is not None:
            subjob_executions: list[ParallelizedExportCollectionSubjobExecution] = []
            subjobs = content.get("subjobs")

            for subjob in subjobs:
                execution = self.get_parallelized_export_log_collections_subjob_status(
                    subjob.get("uuid")
                )
                if execution is not None:
                    subjob_executions.append(execution)
                else:
                    _LOGGER.warning("No job statuses found with subjob uuid %s", subjob.get("uuid"))
                    raise RuntimeError(
                        "No job statuses found with subjob uuid %s", subjob.get("uuid")
                    )
            return subjob_executions
        else:
            _LOGGER.warning("Rerun did not create new executions")
            raise ADPSDKError("Unexpected error when rerunning exports")

    def update_taxonomy_summary_on_log(
        self, log_path: str, taxonomy_updates: list[TaxonomyUpdate]
    ) -> None:
        """
        Edit the taxonomy summary for the given log by providing a list
        of taxonomy updates to make. The taxonomy summary represents all the taxonomies seen
        throughout the duration of the log. Each taxonomy update will be applied to a given node
        within the ODD schema. You can find the relevant node UUID by examining your ODD
        schema description in the Validation Toolset product.

        Args:
            log_path (str): A log path that you want to edit.
            taxonomy_updates (list[TaxonomyUpdate]): A list of taxonomy updates to apply to the log summary.

        Example:
            from adp.public.strada.models import object_models

            taxnomy_updates = [
                object_models.TaxonomyUpdate(
                    node_uuid = "<node_uuid_1>",
                    values = [
                        object_models.TaxonomyAttributeValue.from_value(1),
                        object_models.TaxonomyAttributeValue.from_value(3)
                    ]
                ),
                object_models.TaxonomyUpdate(
                    node_uuid = "<node_uuid_1>",
                    values = [
                        object_models.TaxonomyAttributeValue.from_value("gravel"),
                        object_models.TaxonomyAttributeValue.from_value("asphalt")
                    ]
                )
            ]

            strada_client.update_taxonomy_summary_on_log(log_path = '<log_path>', taxonomy_updates = taxonomy_updates)
        """

        node_updates = []
        for update in taxonomy_updates:
            node_updates.append(
                {
                    "node_uuid": update.node_uuid,
                    "values": [value.asdict() for value in update.values],
                }
            )

        request = {
            "log_path": log_path,
            "partial_taxonomy_summary_update": {"node_updates": node_updates},
        }

        self.post_request(
            API_ENDPOINTS.LOG_TAXONOMY_SUMMARY,
            request,
            "Error while updating taxonomy summary for the specified log.",
        )

    def create_plugin_queue(
        self,
        plugin_queue: PluginQueue,
    ) -> None:
        """
        Creates a new plugin queue.
        In order to use this, non-simulation plugin such as [ExportCollection plugin](/docs/data_explorer/integrating_with_data_explorer/export_collection_plugin/)
        must be implemented.

        [#tags] Public

        Args:
            plugin_queue (PluginQueue): Plugin Queue specification.

        Example:
            strada_api.create_plugin_queue(
                plugin_queue = PluginQueue(
                    name = "queue-1",
                    concurrency_config = PluginQueueConcurrencyConfig(max_concurrent_batches = 1, max_batch_size = 1),
                    scaling_config = PluginQueueScalingConfig(min_replicas = 0, max_replicas = 100, job_scaling_threshold = 5),
                    volumes = [{"name": "v1", "volumeSource": {"emptyDir": {}}}],
                    sidecars = [
                        PluginSidecar(
                            name = "sidecar-1",
                            container_image = "<containerized plugin implemention>",
                            needs_gpu = False,
                            privileged_context = False,
                            entry_point_command = ["python3 plugin_service.py"],
                            args = ["--some_arg", "some_value"],
                            extra_data = {"plugin_server_max_threads": "1"},
                            volume_mounts = [PluginSidecarVolumeMount("v1", "/m1", False)],
                            requests = {},
                            limits = {},
                        )
                    ],
                )
            )
        """

        sidecars = []
        if plugin_queue.sidecars is not None:
            sidecars = [sidecar.asdict() for sidecar in plugin_queue.sidecars]

        request = {
            "plugin_queue": {
                "name": plugin_queue.name,
                "scaling_config": {
                    "min_replicas": plugin_queue.scaling_config.min_replicas,
                    "max_replicas": plugin_queue.scaling_config.max_replicas,
                    "job_scaling_threshold": plugin_queue.scaling_config.job_scaling_threshold,
                },
                "concurrency_config": {
                    "max_concurrent_batches": plugin_queue.concurrency_config.max_concurrent_batches,
                    "max_batch_size": plugin_queue.concurrency_config.max_batch_size,
                },
                "sidecars": sidecars,
                "volume_list": plugin_queue.volumes,
            }
        }

        content = self.post_request(
            API_ENDPOINTS.PLUGIN_QUEUE,
            request,
            "Error creating a new plugin queue",
        )
        if content is None:
            raise ADPSDKError("Error creating plugin queue")

    def get_plugin_queue(self, plugin_queue_name: str) -> PluginQueue:
        """
        Gets the details of a plugin queue

        [#tags] Public

        Args:
            plugin_queue_name (str): The name of the plugin queue.

        Returns:
            PluginQueue: The plugin queue object.

        Example:
            result = strada_api.get_plugin_queue(
                plugin_queue_name="queue-1"
            )
        """
        content = self.post_request_with_path_parameters(
            API_ENDPOINTS.GET_PLUGIN_QUEUE,
            [plugin_queue_name],
            None,
            "Error getting plugin queue",
        )
        if content is None or content.get("pluginQueue") is None:
            raise ADPSDKError("Plugin queue not found")

        return PluginQueue.from_json(content.get("pluginQueue"))

    def update_plugin_queue(
        self,
        plugin_queue: PluginQueue,
    ) -> None:
        """
        Updates a new plugin queue

        [#tags] Public

        Args:
            plugin_queue (PluginQueue): Plugin Queue specification.

        Example:
            strada_api.update_plugin_queue(
                plugin_queue = PluginQueue(
                    name = "queue-1"",
                    concurrency_config = PluginQueueConcurrencyConfig(max_concurrent_batches = 1, max_batch_size = 1),
                    scaling_config = PluginQueueScalingConfig(min_replicas = 0, max_replicas = 100, job_scaling_threshold = 5),
                    volumes = [{"name": "v1", "volumeSource": {"emptyDir": {}}}],
                    sidecars = [
                        PluginSidecar(
                            name = "sidecar-2"",
                            container_image = "quay.io/applied_dev/example_stack:de_export_collection",
                            needs_gpu = False,
                            priviledged_context = False,
                            entry_point_command = ["./example_plugin_service.par"],
                            args = ["--pidfile", "/tmp/export.pid"],
                            extra_data = {"plugin_server_max_threads": "1"},
                            volume_mounts = [PluginSidecarVolumeMount("v1", "/m1", False)],
                            requests = {},
                            limits = {},
                        )
                    ],
                )
            )
        """

        sidecars = []
        if plugin_queue.sidecars is not None:
            sidecars = [sidecar.asdict() for sidecar in plugin_queue.sidecars]

        request = {
            "plugin_queue": {
                "name": plugin_queue.name,
                "scaling_config": {
                    "min_replicas": plugin_queue.scaling_config.min_replicas,
                    "max_replicas": plugin_queue.scaling_config.max_replicas,
                    "job_scaling_threshold": plugin_queue.scaling_config.job_scaling_threshold,
                },
                "concurrency_config": {
                    "max_concurrent_batches": plugin_queue.concurrency_config.max_concurrent_batches,
                    "max_batch_size": plugin_queue.concurrency_config.max_batch_size,
                },
                "sidecars": sidecars,
                "volume_list": plugin_queue.volumes,
            }
        }

        content = self.put_request(
            API_ENDPOINTS.PLUGIN_QUEUE,
            request,
            "Error updating a new plugin queue",
        )
        if content is None:
            raise ADPSDKError("Error updating plugin queue")

    def delete_plugin_queue(self, name: str) -> None:
        """
        Marks a plugin queue for delete

        [#tags] Public

        Args:
            name (str): The name of the plugin queue.

        Example:
            strada_api.delete_plugin_queue(
                name="queue-1"
            )
        """

        content = self.delete_request_with_query_parameters(
            API_ENDPOINTS.DELETE_PLUGIN_QUEUE,
            [name],
            "Error deleting plugin queue",
        )

        if content is None:
            raise ADPSDKError("Plugin queue failed to delete")

    def list_plugin_queues(self) -> list[PluginQueue]:
        """
        Gets the details of all plugin queues

        [#tags] Public

        Returns:
            list[PluginQueue]: List of plugin queue objects.

        Example:
            result = strada_api.list_plugin_queues()
        """
        content = self.post_request(
            API_ENDPOINTS.LIST_PLUGIN_QUEUES,
            None,
            "Error getting plugin queues",
        )
        if content is None or content.get("pluginQueues") is None:
            raise ADPSDKError("Plugin queue not found")

        queues_with_audit_in_json = content.get("pluginQueues")
        plugin_queues: list[PluginQueue] = [
            PluginQueue.from_json(queue_with_audit_dict.get("queue"))
            for queue_with_audit_dict in queues_with_audit_in_json
        ]
        return plugin_queues

    # TODO (#245332) Fix and add search_term back in
    def get_export_log_collections_subjob_logs(
        self,
        subjob_uuid: str,
        sidecar_name: str = "",
    ) -> list[str]:
        """
        Returns logs for a given plugin queue subjob
        [#tags] Public
        Args:
            subjob_uuid (str): The uuid of the subjob for which to retrieve logs.
            cursor (str): Optional cursor to retrieve the next page (100 lines) of logs.

        Returns:
            list[str]: logs from the latest execution subjob

        Example:
            strada_api.get_export_log_collections_subjob_logs(
                subjob_uuid="12345678-1234-1234-1234-123456789ab",
            )
        Exceptions:
            Raises ADPSDKError.
        """
        params = {
            "subjob_uuid": subjob_uuid,
        }
        if sidecar_name:
            params["sidecar_name"] = sidecar_name
        log_compilation: list[str] = []
        try:
            cursor = ""
            while True:
                if cursor:
                    params["cursor"] = cursor
                content = self.get_request(
                    endpoint_enum=API_ENDPOINTS.GET_EXPORT_COLLECTIONS_PLUGIN_LOGS,
                    params=params,
                    error_msg="Error getting logs for subjob",
                )
                log_lines = content.get("logLines")
                if not log_lines:
                    break
                log_compilation = log_lines + log_compilation
                cursor = content.get("cursor")
                if not cursor:
                    break
        except Exception as e:
            raise ADPSDKError from e

        if not log_compilation:
            raise ADPSDKError("Logs not found. Retention policy is 14 days.")
        if isinstance(log_compilation, list) and all(
            isinstance(line, str) for line in log_compilation
        ):
            return log_compilation
        raise ADPSDKError("Unexpected datatype received for logs")

    def fetch_logs(
        self,
        search: SearchFilter,
        log_identifiers: list[LogPath] | None = None,
    ) -> typing.Iterator[Log]:
        """
        Iterator function that queries the log metadata matching the provided search term.
        The iterator yields a log metadata object for the latest conversion of each log.
        The results are sorted by the log conversion date in descending order and pagination is handled internally.

        [#tags] Public

        Args:
            search (SearchFilter): Object that represents a search term/query.
            log_identifiers (list[LogPath] | None, optional): A list of `LogPath` identifier instances to filter the search results by.
        Returns:
            Iterator[Log]: An iterator function which yields for each individual Log object.

        Raises:
            ValueError: If the search term or log_identifiers are not supported.
            RuntimeError: If there was an internal error while querying for the logs.

        Example:
            # Create a search object filtering logs with 'SOME_CUSTOM_FIELD' set to 'some_value' and map name 'Munich'
            custom_field_search = SearchFilter(
                term="customFieldFilter:'SOME_CUSTOM_FIELD,some_value' AND mapName:'Munich'",
                language=SearchLanguage.ADP,
            )
            # Start fetching and iterating over the logs
            logs_iterator = strada_api.fetch_logs(custom_field_search)
            for log in logs_iterator:
                # Do something with the log.
                # Running the query to retrieve the next page of logs is handled internally by the SDK.
                print(log)


            # Create an empty search object (matching any log)
            wildcard_search = SearchFilter(
                term="",
                language=SearchLanguage.ADP,
            )
            log_paths = [LogPath(value="log_path_1"), LogPath(value="log_path_2")]
            # Start fetching and iterating over the logs matching the list of log paths
            logs_iterator = strada_api.fetch_logs(wildcard_search, log_paths)
            for log in logs_iterator:
                print(log)
        """
        return iter_fetch_items(self._post_query_request, Log, search.term, log_identifiers)

    def fetch_events(
        self,
        search: SearchFilter,
        event_identifiers: list[EventUUID] | None = None,
    ) -> typing.Iterator[TriageEvent]:
        """
        Iterator function that queries the event metadata matching the provided search term.
        The iterator yields an event metadata object for each event.
        The results are sorted by the event creation date in descending order and pagination is handled internally.

        [#tags] Public

        Args:
            search (SearchFilter): Object that represents a search term/query.
            event_identifiers (list[str] | None, optional): A list of `EventUUID` identifier instances to filter the search results by.
        Returns:
            Iterator[TriageEvent]: An iterator function which yields for each individual TriageEvent object.

        Raises:
            ValueError: If the search term or event_identifiers are not supported.
            RuntimeError: If there was an internal error while querying for the events.

        Example:
            # Create a search object filtering logs with 'SOME_CUSTOM_FIELD' set to 'some_value' and map name 'Munich'
            search = SearchFilter(
                term="customFieldFilter:'SOME_CUSTOM_FIELD,some_value' AND mapName:'Munich'",
                language=SearchLanguage.ADP,
            )
            # Start fetching and iterating over the events
            events_iterator = strada_api.fetch_events(search)
            for event in events_iterator:
                # Do something with the event.
                # Running the query to retrieve the next page of events is handled internally by the SDK.
                print(event)


            # Create an empty search object (matching any event)
            wildcard_search = SearchFilter(
                term="",
                language=SearchLanguage.ADP,
            )
            event_uuids = [EventUUID(value="event_uuid_1"), EventUUID(value="event_uuid_2")]
            # Start fetching and iterating over the events matching the list of event uuids
            events_iterator = strada_api.fetch_events(wildcard_search, event_uuids)
            for event in events_iterator:
                print(event)
        """
        return iter_fetch_items(
            self._post_query_request, TriageEvent, search.term, event_identifiers
        )
