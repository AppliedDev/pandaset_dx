import contextlib
import os
import sys

from setuptools import setup
from wheel.bdist_wheel import bdist_wheel as _bdist_wheel


class bdist_wheel(_bdist_wheel):
    def finalize_options(self):
        _bdist_wheel.finalize_options(self)
        self.root_is_pure = False
    def get_tag(self):
        python_version = "3.9".replace(".", "")
        python = "cp" + python_version
        abi = "cp" + python_version
        plat = "linux_x86_64"
        return python, abi, plat

# Setuptools provides no native way to adjust logging.
with open(os.devnull, 'w') as fnull, contextlib.redirect_stdout(fnull):
    setup(
        name = "strada_py",
        description = "Strada integration utilities, default plugins, and public interfaces",
        classifiers = ["License :: Other/Proprietary License", "Programming Language :: Python :: 3.7"],
        cmdclass = {"bdist_wheel": bdist_wheel},
        keywords = "autonomous vehicle development",
        url = "https://applied.co",
        author = "Applied Intuition",
        author_email = "contact@applied.co",
        license = "",
        packages = ["adp.public.common", "adp.public.strada", "adp.public.strada.models", "simian.public", "strada.public.log_readers", "strada.public.log_reading_service.proto", "strada.public.message_converters", "simian"],
        package_dir = {"adp.public.common": "adp/public/common", "adp.public.strada": "adp/public/strada", "adp.public.strada.models": "adp/public/strada/models", "simian.public": "simian/public", "strada.public.log_readers": "strada/public/log_readers", "strada.public.log_reading_service.proto": "strada/public/log_reading_service/proto", "strada.public.message_converters": "strada/public/message_converters", "simian": "simian"},
        package_data = {"simian": ["*.so"]},
        data_files = [],
        install_requires = ["simian", "more-itertools==9.0.0", "PyTurboJPEG>=1.7.2"],
        python_requires = "~=3.9",
        version = "0.0.1",
        entry_points={'console_scripts': []},
    )
