from __future__ import annotations

import logging
import os
import subprocess
from typing import Any, Optional, Tuple

import boto3
import genpy
from google.protobuf import timestamp_pb2
from more_itertools import peekable
import rosbag

from simian.public.proto.v2 import io_pb2
from strada.public.log_readers import log_reader_base

logger = logging.getLogger("Ros1Reader")


class Ros1Reader(log_reader_base.LogReaderBase):
    def __init__(self, extra_data: dict = {}) -> None:
        print("configuring reader ", extra_data)
        self._extra_data = extra_data
        self._start_time: genpy.Time = None
        self._end_time: genpy.Time = None
        self._bucket: Optional[str] = None

    # Public API.
    def read_message(self) -> Any:
        message = next(self._bag_iter, (None, None, None))
        return message

    def finished(self) -> bool:
        return self._get_next_timestamp() is None

    def message_available_before(self, offset: timestamp_pb2.Timestamp) -> bool:
        next_ts = self._get_next_timestamp()
        if next_ts is None:
            return False

        current_offset = next_ts - self._start_time
        if current_offset > offset:
            return False

        return True

    def log_open_v2_2(self, log_open_options: io_pb2.LogOpenOptions) -> io_pb2.LogOpenOutput:
        # TODO(def-ai): this is not the right api, but for initial work we can keep this in.
        """
        Called once at the start of the conversion. Does all the work necessary to prepare
        for the conversion, including opening files, querying the DBs, and downloading data.
        The drive start time is returned in the output.
        """
        try:
            logger.info("Converting drive log %s", log_open_options.path)

            self._stack_state_proto = io_pb2.StackState()

            self._bag = self._download_bag(log_open_options.path)
            self._topics_to_types = {
                top: tup.msg_type for top, tup in self._bag.get_type_and_topic_info()[1].items()
            }
            self._start_time, self._end_time = self._get_start_and_end_time(log_open_options)

            # If no include topics are specified, None will tell Rosbag to read ALL topics.
            topics = self._extra_data.get("include", None)
            print("DEBUG: reading topics", topics)

            read_iter = self._bag.read_messages(
                start_time=self._start_time, end_time=self._end_time, topics=topics
            )

            self._bag_iter = peekable(read_iter)
        except Exception as e:
            logger.exception(e)
            raise e
        return io_pb2.LogOpenOutput()

    def log_close(self, _log_close_options: io_pb2.LogCloseOptions) -> None:
        """Called once at the end of the drive conversion."""
        self._bag.close()

    # End Public API.
    def _get_next_timestamp(self) -> genpy.Time:
        try:
            _, _, timestamp = self._bag_iter.peek()
            return timestamp
        except StopIteration:
            return None

    def _get_start_and_end_time(
        self, log_open_options: io_pb2.LogOpenOptions
    ) -> Tuple[genpy.Time, genpy.Time]:
        """Returns the time that we should start reading at and the time that we should read until."""
        # start_offset encodes how far into the bag we should start reading
        start_offset = genpy.Duration(
            secs=log_open_options.start_offset.seconds,
            nsecs=log_open_options.start_offset.nanos,
        )
        start_time = start_offset + genpy.Time(self._bag.get_start_time())
        # max_duration is the maximum amount of drive time that we will return data for
        max_duration = genpy.Duration(
            secs=log_open_options.max_duration.seconds,
            nsecs=log_open_options.max_duration.nanos,
        )
        end_time = start_time + max_duration
        return start_time, end_time

    def _download_bag(self, log_open_path: str) -> rosbag.Bag:
        fpath = log_open_path
        if os.path.exists(fpath):
            logging.info(f"Found cached bag {fpath} locally")  # noqa: G004
            return rosbag.Bag(fpath)

        if not self._bucket:
            logging.warning(
                f"No bucket provided, assuming log path {log_open_path} is local"  # noqa: G004
            )
            fpath = log_open_path

        elif self._bucket.startswith("s3://"):
            client = boto3.client("s3")
            logging.info(f"Downloading log {self._bucket}/{log_open_path}")  # noqa: G004
            client.download_file(self._bucket.replace("s3://", ""), log_open_path, fpath)
        elif self._bucket.startswith("gs://"):
            logging.info(f"Downloading log {self._bucket}/{log_open_path}")  # noqa: G004
            subprocess.run(
                [
                    "/google-cloud-sdk/bin/gsutil",
                    "-m",
                    "cp",
                    os.path.join(self._bucket, log_open_path),
                    fpath,
                ],
                check=True,
            )
        else:
            raise ValueError("Bucket should start with s3:// gs:// but got {self._bucket}")

        return rosbag.Bag(fpath)
